﻿namespace QuanLySinhVien
{
    partial class Begin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Begin));
            this.ribbonControl1 = new DevExpress.XtraBars.Ribbon.RibbonControl();
            this.btn_doimk = new DevExpress.XtraBars.BarButtonItem();
            this.btn_out = new DevExpress.XtraBars.BarButtonItem();
            this.btn_dsaccount = new DevExpress.XtraBars.BarButtonItem();
            this.btn_thoat = new DevExpress.XtraBars.BarButtonItem();
            this.skinRibbonGalleryBarItem1 = new DevExpress.XtraBars.SkinRibbonGalleryBarItem();
            this.skin_theme = new DevExpress.XtraBars.SkinRibbonGalleryBarItem();
            this.update = new DevExpress.XtraBars.BarButtonItem();
            this.btn_info = new DevExpress.XtraBars.BarButtonItem();
            this.cmd = new DevExpress.XtraBars.BarButtonItem();
            this.word = new DevExpress.XtraBars.BarButtonItem();
            this.excel = new DevExpress.XtraBars.BarButtonItem();
            this.hethong = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.fr_hethong = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.btn_capnhat = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.giaodien = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.fr_hotro = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.btn_hotro_1 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.btn_hotro_2 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.accordionControlElement3 = new DevExpress.XtraBars.Navigation.AccordionControlElement();
            this.navBarControl1 = new DevExpress.XtraNavBar.NavBarControl();
            this.qly = new DevExpress.XtraNavBar.NavBarGroup();
            this.ql_gv = new DevExpress.XtraNavBar.NavBarItem();
            this.ql_sinhvien = new DevExpress.XtraNavBar.NavBarItem();
            this.ql_khoa = new DevExpress.XtraNavBar.NavBarItem();
            this.ql_khoa_hoc = new DevExpress.XtraNavBar.NavBarItem();
            this.ql_lop = new DevExpress.XtraNavBar.NavBarItem();
            this.ql_mh = new DevExpress.XtraNavBar.NavBarItem();
            this.nav_small_ketquahoc = new DevExpress.XtraNavBar.NavBarItem();
            this.ql_he = new DevExpress.XtraNavBar.NavBarItem();
            this.timkiem = new DevExpress.XtraNavBar.NavBarGroup();
            this.tk_gv = new DevExpress.XtraNavBar.NavBarItem();
            this.tk_sv = new DevExpress.XtraNavBar.NavBarItem();
            this.tk_khoa = new DevExpress.XtraNavBar.NavBarItem();
            this.tk_khoahoc = new DevExpress.XtraNavBar.NavBarItem();
            this.tk_lop = new DevExpress.XtraNavBar.NavBarItem();
            this.tk_monhoc = new DevExpress.XtraNavBar.NavBarItem();
            this.tk_diem = new DevExpress.XtraNavBar.NavBarItem();
            this.tk_ketqua = new DevExpress.XtraNavBar.NavBarItem();
            this.diem = new DevExpress.XtraNavBar.NavBarGroup();
            this.ds_diem = new DevExpress.XtraNavBar.NavBarItem();
            this.nav_baocao = new DevExpress.XtraNavBar.NavBarGroup();
            this.btn_k = new DevExpress.XtraNavBar.NavBarItem();
            this.xtraTabbedMdiManager1 = new DevExpress.XtraTabbedMdi.XtraTabbedMdiManager(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.navBarControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabbedMdiManager1)).BeginInit();
            this.SuspendLayout();
            // 
            // ribbonControl1
            // 
            this.ribbonControl1.ExpandCollapseItem.Id = 0;
            this.ribbonControl1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.ribbonControl1.ExpandCollapseItem,
            this.btn_doimk,
            this.btn_out,
            this.btn_dsaccount,
            this.btn_thoat,
            this.skinRibbonGalleryBarItem1,
            this.skin_theme,
            this.update,
            this.btn_info,
            this.cmd,
            this.word,
            this.excel});
            this.ribbonControl1.Location = new System.Drawing.Point(0, 0);
            this.ribbonControl1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ribbonControl1.MaxItemId = 12;
            this.ribbonControl1.Name = "ribbonControl1";
            this.ribbonControl1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.hethong,
            this.fr_hotro});
            this.ribbonControl1.Size = new System.Drawing.Size(1200, 144);
            this.ribbonControl1.Click += new System.EventHandler(this.ribbonControl1_Click);
            // 
            // btn_doimk
            // 
            this.btn_doimk.Caption = "Đổi mật khẩu";
            this.btn_doimk.Id = 1;
            this.btn_doimk.ImageOptions.AllowStubGlyph = DevExpress.Utils.DefaultBoolean.False;
            this.btn_doimk.ImageOptions.DisabledImage = ((System.Drawing.Image)(resources.GetObject("btn_doimk.ImageOptions.DisabledImage")));
            this.btn_doimk.ImageOptions.DisabledLargeImage = ((System.Drawing.Image)(resources.GetObject("btn_doimk.ImageOptions.DisabledLargeImage")));
            this.btn_doimk.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_doimk.ImageOptions.Image")));
            this.btn_doimk.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("btn_doimk.ImageOptions.LargeImage")));
            this.btn_doimk.Name = "btn_doimk";
            this.btn_doimk.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btn_doimk_ItemClick);
            // 
            // btn_out
            // 
            this.btn_out.Caption = "Đăng xuất";
            this.btn_out.Id = 2;
            this.btn_out.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_out.ImageOptions.Image")));
            this.btn_out.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("btn_out.ImageOptions.LargeImage")));
            this.btn_out.Name = "btn_out";
            this.btn_out.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btn_out_ItemClick);
            // 
            // btn_dsaccount
            // 
            this.btn_dsaccount.Caption = "Danh sách người dùng";
            this.btn_dsaccount.Id = 3;
            this.btn_dsaccount.ImageOptions.DisabledImage = ((System.Drawing.Image)(resources.GetObject("btn_dsaccount.ImageOptions.DisabledImage")));
            this.btn_dsaccount.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_dsaccount.ImageOptions.Image")));
            this.btn_dsaccount.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("btn_dsaccount.ImageOptions.LargeImage")));
            this.btn_dsaccount.Name = "btn_dsaccount";
            this.btn_dsaccount.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btn_dsaccount_ItemClick);
            // 
            // btn_thoat
            // 
            this.btn_thoat.Caption = "Khóa";
            this.btn_thoat.Id = 4;
            this.btn_thoat.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_thoat.ImageOptions.Image")));
            this.btn_thoat.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("btn_thoat.ImageOptions.LargeImage")));
            this.btn_thoat.Name = "btn_thoat";
            this.btn_thoat.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btn_thoat_ItemClick);
            // 
            // skinRibbonGalleryBarItem1
            // 
            this.skinRibbonGalleryBarItem1.Caption = "skinRibbonGalleryBarItem1";
            this.skinRibbonGalleryBarItem1.Id = 5;
            this.skinRibbonGalleryBarItem1.Name = "skinRibbonGalleryBarItem1";
            // 
            // skin_theme
            // 
            this.skin_theme.Caption = "skinRibbonGalleryBarItem2";
            this.skin_theme.Id = 6;
            this.skin_theme.Name = "skin_theme";
            // 
            // update
            // 
            this.update.Caption = "Cập nhật hệ thống";
            this.update.Id = 7;
            this.update.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("update.ImageOptions.Image")));
            this.update.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("update.ImageOptions.LargeImage")));
            this.update.Name = "update";
            this.update.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.update_ItemClick);
            // 
            // btn_info
            // 
            this.btn_info.Caption = "Thông tin phần mềm";
            this.btn_info.Id = 8;
            this.btn_info.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_info.ImageOptions.Image")));
            this.btn_info.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("btn_info.ImageOptions.LargeImage")));
            this.btn_info.Name = "btn_info";
            this.btn_info.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btn_info_ItemClick);
            // 
            // cmd
            // 
            this.cmd.Caption = "Mở CMD";
            this.cmd.Id = 9;
            this.cmd.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("cmd.ImageOptions.Image")));
            this.cmd.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("cmd.ImageOptions.LargeImage")));
            this.cmd.Name = "cmd";
            this.cmd.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.cmd_ItemClick);
            // 
            // word
            // 
            this.word.Caption = "Mở word";
            this.word.Id = 10;
            this.word.ImageOptions.LargeImage = global::QuanLySinhVien.Properties.Resources.Microsoft_Word_2013_icon;
            this.word.Name = "word";
            this.word.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.word_ItemClick);
            // 
            // excel
            // 
            this.excel.Caption = "Mở Excel";
            this.excel.Id = 11;
            this.excel.ImageOptions.LargeImage = global::QuanLySinhVien.Properties.Resources.Dakirby309_Simply_Styled_Microsoft_Excel_2013;
            this.excel.Name = "excel";
            this.excel.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.excel_ItemClick);
            // 
            // hethong
            // 
            this.hethong.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.fr_hethong,
            this.btn_capnhat,
            this.giaodien});
            this.hethong.Image = ((System.Drawing.Image)(resources.GetObject("hethong.Image")));
            this.hethong.Name = "hethong";
            this.hethong.Text = "Hệ thống";
            // 
            // fr_hethong
            // 
            this.fr_hethong.ItemLinks.Add(this.btn_doimk);
            this.fr_hethong.ItemLinks.Add(this.btn_dsaccount);
            this.fr_hethong.ItemLinks.Add(this.btn_thoat);
            this.fr_hethong.ItemLinks.Add(this.btn_out);
            this.fr_hethong.Name = "fr_hethong";
            this.fr_hethong.Text = "Hệ thống";
            // 
            // btn_capnhat
            // 
            this.btn_capnhat.ItemLinks.Add(this.update);
            this.btn_capnhat.ItemLinks.Add(this.btn_info);
            this.btn_capnhat.Name = "btn_capnhat";
            this.btn_capnhat.Text = "Cập nhật";
            // 
            // giaodien
            // 
            this.giaodien.ItemLinks.Add(this.skin_theme);
            this.giaodien.Name = "giaodien";
            this.giaodien.Text = "Giao diện";
            // 
            // fr_hotro
            // 
            this.fr_hotro.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.btn_hotro_1,
            this.btn_hotro_2});
            this.fr_hotro.Image = ((System.Drawing.Image)(resources.GetObject("fr_hotro.Image")));
            this.fr_hotro.Name = "fr_hotro";
            this.fr_hotro.Text = "Hỗ trợ";
            // 
            // btn_hotro_1
            // 
            this.btn_hotro_1.ItemLinks.Add(this.cmd);
            this.btn_hotro_1.Name = "btn_hotro_1";
            this.btn_hotro_1.Text = "Tiện ích";
            // 
            // btn_hotro_2
            // 
            this.btn_hotro_2.ItemLinks.Add(this.word);
            this.btn_hotro_2.ItemLinks.Add(this.excel);
            this.btn_hotro_2.Name = "btn_hotro_2";
            this.btn_hotro_2.Text = "Office";
            // 
            // accordionControlElement3
            // 
            this.accordionControlElement3.Name = "accordionControlElement3";
            this.accordionControlElement3.Text = "Element3";
            // 
            // navBarControl1
            // 
            this.navBarControl1.ActiveGroup = this.qly;
            this.navBarControl1.Dock = System.Windows.Forms.DockStyle.Left;
            this.navBarControl1.Groups.AddRange(new DevExpress.XtraNavBar.NavBarGroup[] {
            this.qly,
            this.timkiem,
            this.diem,
            this.nav_baocao});
            this.navBarControl1.Items.AddRange(new DevExpress.XtraNavBar.NavBarItem[] {
            this.ql_sinhvien,
            this.ql_gv,
            this.ql_khoa,
            this.ql_khoa_hoc,
            this.ql_lop,
            this.ql_mh,
            this.tk_gv,
            this.tk_sv,
            this.tk_khoa,
            this.tk_khoahoc,
            this.tk_lop,
            this.tk_monhoc,
            this.ds_diem,
            this.ql_he,
            this.tk_diem,
            this.nav_small_ketquahoc,
            this.btn_k,
            this.tk_ketqua});
            this.navBarControl1.Location = new System.Drawing.Point(0, 144);
            this.navBarControl1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.navBarControl1.Name = "navBarControl1";
            this.navBarControl1.OptionsNavPane.ExpandedWidth = 256;
            this.navBarControl1.PaintStyleKind = DevExpress.XtraNavBar.NavBarViewKind.ExplorerBar;
            this.navBarControl1.Size = new System.Drawing.Size(256, 568);
            this.navBarControl1.TabIndex = 2;
            this.navBarControl1.Text = "navBarControl1";
            this.navBarControl1.Click += new System.EventHandler(this.navBarControl1_Click);
            // 
            // qly
            // 
            this.qly.Caption = "Quản lý";
            this.qly.Expanded = true;
            this.qly.ItemLinks.AddRange(new DevExpress.XtraNavBar.NavBarItemLink[] {
            new DevExpress.XtraNavBar.NavBarItemLink(this.ql_gv),
            new DevExpress.XtraNavBar.NavBarItemLink(this.ql_sinhvien),
            new DevExpress.XtraNavBar.NavBarItemLink(this.ql_khoa),
            new DevExpress.XtraNavBar.NavBarItemLink(this.ql_khoa_hoc),
            new DevExpress.XtraNavBar.NavBarItemLink(this.ql_lop),
            new DevExpress.XtraNavBar.NavBarItemLink(this.ql_mh),
            new DevExpress.XtraNavBar.NavBarItemLink(this.nav_small_ketquahoc),
            new DevExpress.XtraNavBar.NavBarItemLink(this.ql_he)});
            this.qly.LargeImage = ((System.Drawing.Image)(resources.GetObject("qly.LargeImage")));
            this.qly.Name = "qly";
            // 
            // ql_gv
            // 
            this.ql_gv.Caption = "Giáo viên";
            this.ql_gv.Name = "ql_gv";
            this.ql_gv.SmallImage = ((System.Drawing.Image)(resources.GetObject("ql_gv.SmallImage")));
            this.ql_gv.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.ql_gv_LinkClicked);
            // 
            // ql_sinhvien
            // 
            this.ql_sinhvien.Caption = "Sinh viên";
            this.ql_sinhvien.LargeImage = ((System.Drawing.Image)(resources.GetObject("ql_sinhvien.LargeImage")));
            this.ql_sinhvien.Name = "ql_sinhvien";
            this.ql_sinhvien.SmallImage = ((System.Drawing.Image)(resources.GetObject("ql_sinhvien.SmallImage")));
            this.ql_sinhvien.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.ql_sinhvien_LinkClicked);
            // 
            // ql_khoa
            // 
            this.ql_khoa.Caption = "Khoa";
            this.ql_khoa.Name = "ql_khoa";
            this.ql_khoa.SmallImage = ((System.Drawing.Image)(resources.GetObject("ql_khoa.SmallImage")));
            this.ql_khoa.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.ql_khoa_LinkClicked);
            // 
            // ql_khoa_hoc
            // 
            this.ql_khoa_hoc.Caption = "Khóa học";
            this.ql_khoa_hoc.Name = "ql_khoa_hoc";
            this.ql_khoa_hoc.SmallImage = ((System.Drawing.Image)(resources.GetObject("ql_khoa_hoc.SmallImage")));
            this.ql_khoa_hoc.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.ql_khoa_hoc_LinkClicked);
            // 
            // ql_lop
            // 
            this.ql_lop.Caption = "Lớp học";
            this.ql_lop.Name = "ql_lop";
            this.ql_lop.SmallImage = ((System.Drawing.Image)(resources.GetObject("ql_lop.SmallImage")));
            this.ql_lop.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.ql_lop_LinkClicked);
            // 
            // ql_mh
            // 
            this.ql_mh.Caption = "Môn học";
            this.ql_mh.Name = "ql_mh";
            this.ql_mh.SmallImage = ((System.Drawing.Image)(resources.GetObject("ql_mh.SmallImage")));
            this.ql_mh.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.ql_mh_LinkClicked);
            // 
            // nav_small_ketquahoc
            // 
            this.nav_small_ketquahoc.Caption = "Kết quả học tập";
            this.nav_small_ketquahoc.Name = "nav_small_ketquahoc";
            this.nav_small_ketquahoc.SmallImage = ((System.Drawing.Image)(resources.GetObject("nav_small_ketquahoc.SmallImage")));
            this.nav_small_ketquahoc.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.nav_small_ketquahoc_LinkClicked);
            // 
            // ql_he
            // 
            this.ql_he.Caption = "Hệ giảng dạy";
            this.ql_he.Name = "ql_he";
            this.ql_he.SmallImage = ((System.Drawing.Image)(resources.GetObject("ql_he.SmallImage")));
            this.ql_he.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.ql_he_LinkClicked);
            // 
            // timkiem
            // 
            this.timkiem.Caption = "Tìm kiếm";
            this.timkiem.Expanded = true;
            this.timkiem.ItemLinks.AddRange(new DevExpress.XtraNavBar.NavBarItemLink[] {
            new DevExpress.XtraNavBar.NavBarItemLink(this.tk_gv),
            new DevExpress.XtraNavBar.NavBarItemLink(this.tk_sv),
            new DevExpress.XtraNavBar.NavBarItemLink(this.tk_khoa),
            new DevExpress.XtraNavBar.NavBarItemLink(this.tk_khoahoc),
            new DevExpress.XtraNavBar.NavBarItemLink(this.tk_lop),
            new DevExpress.XtraNavBar.NavBarItemLink(this.tk_monhoc),
            new DevExpress.XtraNavBar.NavBarItemLink(this.tk_diem),
            new DevExpress.XtraNavBar.NavBarItemLink(this.tk_ketqua)});
            this.timkiem.Name = "timkiem";
            this.timkiem.SmallImage = ((System.Drawing.Image)(resources.GetObject("timkiem.SmallImage")));
            // 
            // tk_gv
            // 
            this.tk_gv.Caption = "Giáo viên";
            this.tk_gv.LargeImage = ((System.Drawing.Image)(resources.GetObject("tk_gv.LargeImage")));
            this.tk_gv.Name = "tk_gv";
            this.tk_gv.SmallImage = ((System.Drawing.Image)(resources.GetObject("tk_gv.SmallImage")));
            this.tk_gv.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.tk_gv_LinkClicked);
            // 
            // tk_sv
            // 
            this.tk_sv.Caption = "Sinh viên";
            this.tk_sv.Name = "tk_sv";
            this.tk_sv.SmallImage = ((System.Drawing.Image)(resources.GetObject("tk_sv.SmallImage")));
            this.tk_sv.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.tk_sv_LinkClicked);
            // 
            // tk_khoa
            // 
            this.tk_khoa.Caption = "Khoa";
            this.tk_khoa.Name = "tk_khoa";
            this.tk_khoa.SmallImage = ((System.Drawing.Image)(resources.GetObject("tk_khoa.SmallImage")));
            this.tk_khoa.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.tk_khoa_LinkClicked);
            // 
            // tk_khoahoc
            // 
            this.tk_khoahoc.Caption = "Khóa học";
            this.tk_khoahoc.Name = "tk_khoahoc";
            this.tk_khoahoc.SmallImage = ((System.Drawing.Image)(resources.GetObject("tk_khoahoc.SmallImage")));
            this.tk_khoahoc.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.tk_khoahoc_LinkClicked);
            // 
            // tk_lop
            // 
            this.tk_lop.Caption = "Lớp học";
            this.tk_lop.Name = "tk_lop";
            this.tk_lop.SmallImage = ((System.Drawing.Image)(resources.GetObject("tk_lop.SmallImage")));
            this.tk_lop.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.tk_lop_LinkClicked);
            // 
            // tk_monhoc
            // 
            this.tk_monhoc.Caption = "Môn học";
            this.tk_monhoc.Name = "tk_monhoc";
            this.tk_monhoc.SmallImage = ((System.Drawing.Image)(resources.GetObject("tk_monhoc.SmallImage")));
            this.tk_monhoc.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.tk_monhoc_LinkClicked);
            // 
            // tk_diem
            // 
            this.tk_diem.Caption = "Điểm";
            this.tk_diem.LargeImage = ((System.Drawing.Image)(resources.GetObject("tk_diem.LargeImage")));
            this.tk_diem.Name = "tk_diem";
            this.tk_diem.SmallImage = ((System.Drawing.Image)(resources.GetObject("tk_diem.SmallImage")));
            this.tk_diem.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.tk_diem_LinkClicked);
            // 
            // tk_ketqua
            // 
            this.tk_ketqua.Caption = "Kết quả học tập";
            this.tk_ketqua.Name = "tk_ketqua";
            this.tk_ketqua.SmallImage = ((System.Drawing.Image)(resources.GetObject("tk_ketqua.SmallImage")));
            this.tk_ketqua.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.tk_ketqua_LinkClicked);
            // 
            // diem
            // 
            this.diem.Caption = "Điểm";
            this.diem.ItemLinks.AddRange(new DevExpress.XtraNavBar.NavBarItemLink[] {
            new DevExpress.XtraNavBar.NavBarItemLink(this.ds_diem)});
            this.diem.Name = "diem";
            this.diem.SmallImage = ((System.Drawing.Image)(resources.GetObject("diem.SmallImage")));
            // 
            // ds_diem
            // 
            this.ds_diem.Caption = "Nhập điểm";
            this.ds_diem.Name = "ds_diem";
            this.ds_diem.SmallImage = ((System.Drawing.Image)(resources.GetObject("ds_diem.SmallImage")));
            this.ds_diem.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.ds_diem_LinkClicked);
            // 
            // nav_baocao
            // 
            this.nav_baocao.Caption = "Báo cáo thống kê";
            this.nav_baocao.ItemLinks.AddRange(new DevExpress.XtraNavBar.NavBarItemLink[] {
            new DevExpress.XtraNavBar.NavBarItemLink(this.btn_k)});
            this.nav_baocao.Name = "nav_baocao";
            this.nav_baocao.SmallImage = ((System.Drawing.Image)(resources.GetObject("nav_baocao.SmallImage")));
            // 
            // btn_k
            // 
            this.btn_k.Caption = "Thống kê";
            this.btn_k.Name = "btn_k";
            this.btn_k.SmallImage = ((System.Drawing.Image)(resources.GetObject("btn_k.SmallImage")));
            this.btn_k.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.btn_k_LinkClicked);
            // 
            // xtraTabbedMdiManager1
            // 
            this.xtraTabbedMdiManager1.MdiParent = this;
            // 
            // Begin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 712);
            this.Controls.Add(this.navBarControl1);
            this.Controls.Add(this.ribbonControl1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Begin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Màn hình chính";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Begin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.navBarControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabbedMdiManager1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl1;
        private DevExpress.XtraBars.Ribbon.RibbonPage hethong;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup fr_hethong;
        private DevExpress.XtraBars.Ribbon.RibbonPage fr_hotro;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup btn_hotro_1;
        private DevExpress.XtraBars.Navigation.AccordionControlElement accordionControlElement3;
        private DevExpress.XtraNavBar.NavBarControl navBarControl1;
        private DevExpress.XtraBars.BarButtonItem btn_doimk;
        private DevExpress.XtraBars.BarButtonItem btn_out;
        private DevExpress.XtraBars.BarButtonItem btn_thoat;
        private DevExpress.XtraTabbedMdi.XtraTabbedMdiManager xtraTabbedMdiManager1;
        public DevExpress.XtraNavBar.NavBarItem ql_gv;
        public DevExpress.XtraNavBar.NavBarItem ql_khoa_hoc;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup giaodien;
        private DevExpress.XtraNavBar.NavBarGroup timkiem;
        private DevExpress.XtraNavBar.NavBarItem ds_diem;
        private DevExpress.XtraBars.SkinRibbonGalleryBarItem skinRibbonGalleryBarItem1;
        private DevExpress.XtraBars.SkinRibbonGalleryBarItem skin_theme;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup btn_hotro_2;
        private DevExpress.XtraBars.BarButtonItem update;
        private DevExpress.XtraBars.BarButtonItem btn_info;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup btn_capnhat;
        public DevExpress.XtraNavBar.NavBarGroup qly;
        public DevExpress.XtraNavBar.NavBarItem ql_sinhvien;
        public DevExpress.XtraBars.BarButtonItem btn_dsaccount;
        public DevExpress.XtraNavBar.NavBarItem ql_khoa;
        public DevExpress.XtraNavBar.NavBarItem ql_lop;
        public DevExpress.XtraNavBar.NavBarItem ql_mh;
        public DevExpress.XtraNavBar.NavBarItem tk_gv;
        public DevExpress.XtraNavBar.NavBarItem tk_sv;
        public DevExpress.XtraNavBar.NavBarItem tk_khoa;
        public DevExpress.XtraNavBar.NavBarItem tk_khoahoc;
        public DevExpress.XtraNavBar.NavBarItem tk_lop;
        public DevExpress.XtraNavBar.NavBarItem tk_monhoc;
        public DevExpress.XtraNavBar.NavBarGroup diem;
        public DevExpress.XtraNavBar.NavBarItem ql_he;
        public DevExpress.XtraNavBar.NavBarItem tk_diem;
        private DevExpress.XtraNavBar.NavBarItem nav_small_ketquahoc;
        private DevExpress.XtraNavBar.NavBarItem btn_k;
        private DevExpress.XtraBars.BarButtonItem cmd;
        private DevExpress.XtraBars.BarButtonItem word;
        private DevExpress.XtraBars.BarButtonItem excel;
        public DevExpress.XtraNavBar.NavBarGroup nav_baocao;
        private DevExpress.XtraNavBar.NavBarItem tk_ketqua;
    }
}