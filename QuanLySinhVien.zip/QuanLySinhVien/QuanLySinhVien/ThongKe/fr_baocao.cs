﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySinhVien.ThongKe
{
    public partial class fr_baocao : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=QLSV;Integrated Security=True");

        public fr_baocao()
        {
            InitializeComponent();
        }
        public void hienthi()
        {
            conn.Open();
            String sql = "select * from KETQUA";
            SqlCommand cmd = new SqlCommand(sql, conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            conn.Close();
            ds.DataSource = dt;

        }
        private void fr_baocao_Load(object sender, EventArgs e)
        {
            hienthi();
        }

        private void btn_timkiem_Click(object sender, EventArgs e)
        {
            try
            {
                if (com_list.Text == "")
                {
                    MessageBox.Show("Bạn chưa chọn tìm kiếm theo !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    com_list.Focus();
                }
                else
                {
                   
                            Boolean kt = false;
                            int count;
                            conn.Open();
                            SqlCommand cmd1 = new SqlCommand("SELECT count(*) FROM KETQUA where tinhtrang like N'%giỏi%'", conn);
                            count = (int)cmd1.ExecuteScalar();
                            conn.Close();
                            if (count != 0 && com_list.Text == "Sinh viên đạt học bổng")
                            {
                                kt = true;
                            }
                            if (kt == true)
                            {
                                MessageBox.Show("Tìm thấy dữ liệu !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

                                conn.Open();
                                SqlCommand com = new SqlCommand("SELECT * FROM KETQUA where tinhtrang like N'%giỏi%'", conn);
                                SqlDataAdapter da1 = new SqlDataAdapter(com);
                                DataTable dt1 = new DataTable();
                                da1.Fill(dt1);
                                ds.DataSource = dt1;
                                conn.Close();
                            }
                            else
                            {
                                conn.Open();
                                SqlCommand show = new SqlCommand("SELECT count(*) FROM KETQUA where tinhtrang like N't%'", conn);
                                count = (int)show.ExecuteScalar();
                                conn.Close();
                                if (count != 0 && com_list.Text == "Sinh viên bị cảnh cáo học tập")
                                {
                                    kt = true;
                                }
                                if (kt == true)
                                {
                                    MessageBox.Show("Tìm thấy dữ liệu !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

                                    conn.Open();
                                    SqlCommand com = new SqlCommand("SELECT * FROM KETQUA where tinhtrang like N't%'", conn);
                                    SqlDataAdapter da2 = new SqlDataAdapter(com);
                                    DataTable dt2 = new DataTable();
                                    da2.Fill(dt2);
                                    ds.DataSource = dt2;
                                    conn.Close();
                        }
                        else
                        {
                            conn.Open();
                            SqlCommand show1 = new SqlCommand("SELECT count(*) FROM KETQUA where tinhtrang like N'y%'", conn);
                            count = (int)show1.ExecuteScalar();
                            conn.Close();
                            if (count != 0 && com_list.Text == "Sinh viên học lại")
                            {
                                kt = true;
                            }
                            if (kt == true)
                            {
                                MessageBox.Show("Tìm thấy dữ liệu !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

                                conn.Open();
                                SqlCommand com = new SqlCommand("SELECT * FROM KETQUA where tinhtrang like N'y%'", conn);
                                SqlDataAdapter da2 = new SqlDataAdapter(com);
                                DataTable dt2 = new DataTable();
                                da2.Fill(dt2);
                                ds.DataSource = dt2;
                                conn.Close();
                            }
                            else
                            {
                                conn.Open();
                                SqlCommand cmd3 = new SqlCommand("SELECT count(*) FROM KETQUA where tinhtrang like N'%giỏi%' OR tinhtrang like N'%khá%'", conn);
                                count = (int)cmd3.ExecuteScalar();
                                conn.Close();
                                if (count != 0 && com_list.Text == "Sinh viên học tiếp")
                                {
                                    kt = true;
                                }
                                if (kt == true)
                                {
                                    MessageBox.Show("Tìm thấy dữ liệu !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

                                    conn.Open();
                                    SqlCommand com = new SqlCommand("SELECT * FROM KETQUA where tinhtrang like N'%giỏi%' OR tinhtrang like N'%khá%'", conn);
                                    SqlDataAdapter da1 = new SqlDataAdapter(com);
                                    DataTable dt1 = new DataTable();
                                    da1.Fill(dt1);
                                    ds.DataSource = dt1;
                                    conn.Close();
                                }
                            }
                        }
                     }
                    
                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_load_Click(object sender, EventArgs e)
        {
            hienthi();
            com_list.Text = "";
        }

        private void btn_export_Click(object sender, EventArgs e)
        {
            //khởi tạo excel
            Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();
            //khởi tạo WorkBook
            Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
            //khởi tạo WorkSheet
            Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
            worksheet = workbook.Sheets["Sheet1"];
            worksheet = workbook.ActiveSheet;
            app.Visible = true;
            //đổ dữ liệu vào sheet
            worksheet.Cells[1, 1] = "....., Ngày... tháng... năm......";
            worksheet.Cells[2, 1] = "Danh sách xem sét tiến độ của sinh viên";
            worksheet.Cells[3, 1] = "STT";
            worksheet.Cells[3, 2] = "Mã sinh viên";
            worksheet.Cells[3, 3] = "Mã môn học";
            worksheet.Cells[3, 4] = "Điểm lớp";
            worksheet.Cells[3, 5] = "Điểm tổng kết";
            worksheet.Cells[3, 6] = "Tình trạng";
            worksheet.Cells[3, 7] = "Ghi chú";
            for (int i = 0; i < ds.RowCount - 1; i++)
            {
                for (int j = 0; j < 6; j++)
                {
                    worksheet.Cells[i + 4, 1] = i + 1;
                    worksheet.Cells[i + 4, j + 2] = ds.Rows[i].Cells[j].Value;
                }
            }
            worksheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
            worksheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;
            worksheet.PageSetup.LeftMargin = 0;
            worksheet.PageSetup.RightMargin = 0;
            worksheet.PageSetup.TopMargin = 0;
            worksheet.PageSetup.BottomMargin = 0;
            worksheet.PageSetup.CenterHorizontally = true;

            //định dạng cột
            worksheet.Range["A1"].ColumnWidth = 5;
            worksheet.Range["B1"].ColumnWidth = 11.3;
            worksheet.Range["C1"].ColumnWidth = 16.78;
            worksheet.Range["D1"].ColumnWidth = 11.89;
            worksheet.Range["E1"].ColumnWidth = 14.78;
            worksheet.Range["F1"].ColumnWidth = 7.11;

            worksheet.Range["A1", "F100"].Font.Name = "Times New Roman";
            worksheet.Range["A1", "F100"].Font.Size = 12;
            worksheet.Range["A1", "F1"].MergeCells = true;
            worksheet.Range["A2", "G2"].MergeCells = true;
            worksheet.Range["A2", "G2"].Font.Bold = true;

            worksheet.Range["A3", "F" + (ds.RowCount + 2)].Borders.LineStyle = 1;

            worksheet.Range["A1", "F1"].HorizontalAlignment = 4;
            worksheet.Range["A2", "F2"].HorizontalAlignment = 3;
            worksheet.Range["A3", "A" + (ds.RowCount + 2)].HorizontalAlignment = 3;
            worksheet.Range["A3", "F3"].HorizontalAlignment = 3;
        }
    }
}

