﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace QuanLySinhVien.ThongKe
{
    public partial class fr_ketqua : Form
    {

        connectDB conn = new connectDB();
        public fr_ketqua()
        {
            InitializeComponent();
        }
        public void hienthi()
        {
            conn.Open();
            String sql = "select * from KETQUA";
            SqlCommand cmd = new SqlCommand(sql, conn.Connect());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            conn.Close();
            ds.DataSource = dt;

        }
        public void load_masv()
        {
            conn.Open();
            string sql = "select masv from SINHVIEN";
            SqlCommand cmd = new SqlCommand(sql, conn.Connect());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet set = new DataSet();
            da.Fill(set, "Chọn điểm lần 1");
            com_masv.DataSource = set.Tables[0];
            com_masv.DisplayMember = "masv";
            com_masv.ValueMember = "masv";
            conn.Close();
        }
        public void load_mon()
        {
            conn.Open();
            string sql = "select mamh from DIEM where masv='"+com_masv.Text+"'";
            SqlCommand cmd = new SqlCommand(sql, conn.Connect());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet set = new DataSet();
            da.Fill(set, "Chọn điểm lần 1");
            com_mon.DataSource = set.Tables[0];
            com_mon.DisplayMember = "mamh";
            com_mon.ValueMember = "mamh";
            conn.Close();
        }
        public void load_lop()
        {
            conn.Open();
            string sql = "select malop from SINHVIEN where masv='" + com_masv.Text + "'";
            SqlCommand cmd = new SqlCommand(sql, conn.Connect());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet set = new DataSet();
            da.Fill(set, "Chọn điểm lần 1");
            com_lop.DataSource = set.Tables[0];
            com_lop.DisplayMember = "malop";
            com_lop.ValueMember = "malop";
            conn.Close();
        }
        public void show_sinhvien(String txt)
        {
            string sql1 = "select SINHVIEN.tensv from SINHVIEN,DIEM where SINHViEN.masv=DIEM.masv and SINHVIEN.masv='"+com_masv.Text+"'";
            SqlCommand cmd1 = new SqlCommand(sql1, conn.Connect());
            SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
            DataTable dt1 = new DataTable();
            da1.Fill(dt1);
            String tensinhvien = "";
            foreach (DataRow r in dt1.Rows)
            {
                tensinhvien = r["tensv"].ToString();
            }
            txt_tensinhvien.Text = tensinhvien.ToString();

        }
        public void show_monhoc(String txt)
        {
            string sql1 = "select MONHOC.tenmh from MONHOC,DIEM where MONHOC.mamh=DIEM.mamh and MONHOC.mamh='" + com_mon.Text + "'";
            SqlCommand cmd1 = new SqlCommand(sql1, conn.Connect());
            SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
            DataTable dt1 = new DataTable();
            da1.Fill(dt1);
            String tensinhvien = "";
            foreach (DataRow r in dt1.Rows)
            {
                tensinhvien = r["tenmh"].ToString();
            }
            txt_tenmh.Text = tensinhvien.ToString();

        }
        public void show_lophoc(String txt)
        {
            string sql1 = "select tenlop from LOP where malop='" + com_lop.Text + "'";
            SqlCommand cmd1 = new SqlCommand(sql1, conn.Connect());
            SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
            DataTable dt1 = new DataTable();
            da1.Fill(dt1);
            String tenlop = "";
            foreach (DataRow r in dt1.Rows)
            {
                tenlop = r["tenlop"].ToString();
            }
            txt_tenlop.Text = tenlop.ToString();

        }
        private void fr_ketqua_Load(object sender, EventArgs e)
        {
            //hientho
            hienthi();
            this.load_mon();
            this.load_masv();
            this.load_lop();
            //load
            String txt = com_masv.Text;
            this.show_sinhvien(txt);
            String txt1 = com_mon.Text;
            this.show_monhoc(txt1);
            String txt2 = com_lop.Text;
            this.show_lophoc(txt2);

            //load diem
            this.show_diem();
        }

        private void com_masv_SelectedIndexChanged(object sender, EventArgs e)
        {
            String txt = com_masv.Text;
            this.show_sinhvien(txt);
            this.load_mon();
            this.load_lop();
            this.show_diem();
        }


        public void show_diem()
        {
            conn.Open();
            String sql = "select diemlan1,diemlan2 from DIEM where masv='" + com_masv.Text + "' and mamh='" + com_mon.Text + "'";
            SqlCommand cmd = new SqlCommand(sql, conn.Connect());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            conn.Close();
            String diem1 = "";
            String diem2 = "";
            double a;
            double b=0;
            double kq;
            foreach (DataRow r in dt.Rows)
            {
                diem1 = r["diemlan1"].ToString();
                diem2 = r["diemlan2"].ToString();
                
                if (diem2 != "" && diem1 != "")
                {
                    a = Convert.ToDouble(diem1.ToString());
                    b = Convert.ToDouble(diem2.ToString());
                    if (b < a)
                    {
                        kq = ((a * 60) + (8 * 40)) / 100;
                        txt_diemtb.Text = kq.ToString();
                        xeploai(kq);
                    }
                    else
                    {
                        kq = ((b * 40) + (8 * 60)) / 100;
                        txt_diemtb.Text = kq.ToString();
                        xeploai(kq);
                    }

                }
                else if(diem1!="")
                {
                    a = Convert.ToDouble(diem1.ToString());
                    kq = ((a * 40) + (8 * 60)) / 100;
                    txt_diemtb.Text = kq.ToString();
                    xeploai(kq);
                }
            }
           
            txt_diem.Text = diem1.ToString();
            txt_diemthi.Text = diem2.ToString();

        }


        public void xeploai(double a)
        {
            if (a > 8)
            {
                txt_xeploai.Text = "Giỏi";
                txt_ghichu.Text = "Học tiếp";
            }
            else if(a < 8 && a >= 6.5)
            {
                txt_xeploai.Text = "Khá";
                txt_ghichu.Text = "Học tiếp";
            }
            else if (a < 6.5 && a > 5)
            {
                txt_xeploai.Text = "Trung bình";
                txt_ghichu.Text = "Học tiếp";
            }
            else if (a < 5 && a > 3)
            {
                txt_xeploai.Text = "Trung bình Yếu";
                txt_ghichu.Text = "Cảnh cáo";
            }
            else if(a<3)
            {
                txt_xeploai.Text = "Yếu";
                txt_ghichu.Text = "Học lại";
            }

        }
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void com_mon_SelectedIndexChanged(object sender, EventArgs e)
        {
            String txt1 = com_mon.Text;
            this.show_monhoc(txt1);
            this.show_diem();
        }

        private void com_lop_SelectedIndexChanged(object sender, EventArgs e)
        {
            String txt2 = com_lop.Text;
            this.show_lophoc(txt2);
        }

        private void btn_them_Click(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                string show = "select mamh from KETQUA where mamh='" + com_mon.Text + "'";
                SqlCommand c = new SqlCommand(show, conn.Connect());
                SqlDataAdapter da1 = new SqlDataAdapter(c);
                DataTable dt1 = new DataTable();
                da1.Fill(dt1);
                conn.Close();
                string mamon = "";
                foreach(DataRow r in dt1.Rows)
                {
                    mamon = r["mamh"].ToString();
                }
                if (com_mon.Text == mamon)
                {
                    MessageBox.Show("Mã môn bạn nhập hiện tại đã có điểm. Mời bạn ấn cập nhật !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    btn_capnhat.Focus();
                }
                else
                {
                    conn.Open();
                    String sql = "insert into KETQUA (masv,mamh,malop,diemtb,tinhtrang,ghichu)" +
                        "values('"+com_masv.Text+ "','" + com_mon.Text + "','" + com_lop.Text + "','" + txt_diemtb.Text + "',N'" + txt_xeploai.Text + "',N'" + txt_ghichu.Text + "')";
                    conn.Excute(sql);
                    MessageBox.Show("Thêm điểm cho sinh viên thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    hienthi();
                }

            }catch(Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_capnhat_Click(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                string show = "select mamh from KETQUA where mamh='" + com_mon.Text + "'";
                SqlCommand c = new SqlCommand(show, conn.Connect());
                SqlDataAdapter da1 = new SqlDataAdapter(c);
                DataTable dt1 = new DataTable();
                da1.Fill(dt1);
                conn.Close();
                string mamon = "";
                foreach (DataRow r in dt1.Rows)
                {
                    mamon = r["mamh"].ToString();
                }
                if (com_mon.Text != mamon)
                {
                    MessageBox.Show("Mã môn bạn nhập hiện tại không tồn tại !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    btn_capnhat.Focus();
                }
                else
                {
                    conn.Open();
                    String sql = "update KETQUA set malop='" + com_lop.Text + "',diemtb='" + txt_diemtb.Text + "',tinhtrang=N'" + txt_xeploai.Text + "',ghichu=N'" + txt_ghichu.Text + "' where masv='"+com_masv.Text+"' and mamh='"+com_mon.Text+"'";
                    conn.Excute(sql);
                    
                    MessageBox.Show("Cập nhật điểm cho sinh viên thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    hienthi();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
