﻿namespace QuanLySinhVien.ThongKe
{
    partial class fr_ketqua
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fr_ketqua));
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_capnhat = new DevExpress.XtraEditors.SimpleButton();
            this.txt_xeploai = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txt_diemtb = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_diemthi = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_diem = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_tenlop = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.com_lop = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_tenmh = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_tensinhvien = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.com_mon = new System.Windows.Forms.ComboBox();
            this.com_masv = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.ds = new System.Windows.Forms.DataGridView();
            this.masv = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mamh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.malop = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.diemtb = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tinhtrang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ghichu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_them = new DevExpress.XtraEditors.SimpleButton();
            this.txt_ghichu = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ds)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(360, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(363, 39);
            this.label1.TabIndex = 0;
            this.label1.Text = "Kết quả của sinh viên";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txt_ghichu);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.btn_them);
            this.groupBox1.Controls.Add(this.btn_capnhat);
            this.groupBox1.Controls.Add(this.txt_xeploai);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.txt_diemtb);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.txt_diemthi);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.txt_diem);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txt_tenlop);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.com_lop);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txt_tenmh);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txt_tensinhvien);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.com_mon);
            this.groupBox1.Controls.Add(this.com_masv);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(25, 62);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1053, 243);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin về điểm sinh viên";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // btn_capnhat
            // 
            this.btn_capnhat.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.btn_capnhat.Appearance.Options.UseFont = true;
            this.btn_capnhat.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_capnhat.ImageOptions.Image")));
            this.btn_capnhat.ImageOptions.ImageToTextIndent = -10;
            this.btn_capnhat.Location = new System.Drawing.Point(851, 173);
            this.btn_capnhat.Margin = new System.Windows.Forms.Padding(50, 3, 3, 3);
            this.btn_capnhat.Name = "btn_capnhat";
            this.btn_capnhat.Size = new System.Drawing.Size(121, 37);
            this.btn_capnhat.TabIndex = 27;
            this.btn_capnhat.Text = "Cập nhật";
            this.btn_capnhat.Click += new System.EventHandler(this.btn_capnhat_Click);
            // 
            // txt_xeploai
            // 
            this.txt_xeploai.Location = new System.Drawing.Point(812, 90);
            this.txt_xeploai.Name = "txt_xeploai";
            this.txt_xeploai.ReadOnly = true;
            this.txt_xeploai.Size = new System.Drawing.Size(160, 26);
            this.txt_xeploai.TabIndex = 26;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(716, 96);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(66, 20);
            this.label11.TabIndex = 25;
            this.label11.Text = "Xếp loại";
            // 
            // txt_diemtb
            // 
            this.txt_diemtb.Location = new System.Drawing.Point(812, 44);
            this.txt_diemtb.Name = "txt_diemtb";
            this.txt_diemtb.ReadOnly = true;
            this.txt_diemtb.Size = new System.Drawing.Size(160, 26);
            this.txt_diemtb.TabIndex = 24;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(716, 50);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(70, 20);
            this.label10.TabIndex = 23;
            this.label10.Text = "Điểm TB";
            // 
            // txt_diemthi
            // 
            this.txt_diemthi.Location = new System.Drawing.Point(524, 184);
            this.txt_diemthi.Name = "txt_diemthi";
            this.txt_diemthi.ReadOnly = true;
            this.txt_diemthi.Size = new System.Drawing.Size(160, 26);
            this.txt_diemthi.TabIndex = 22;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(428, 190);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(86, 20);
            this.label9.TabIndex = 21;
            this.label9.Text = "Điểm thi lại";
            // 
            // txt_diem
            // 
            this.txt_diem.Location = new System.Drawing.Point(524, 137);
            this.txt_diem.Name = "txt_diem";
            this.txt_diem.ReadOnly = true;
            this.txt_diem.Size = new System.Drawing.Size(160, 26);
            this.txt_diem.TabIndex = 20;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(428, 143);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 20);
            this.label4.TabIndex = 19;
            this.label4.Text = "Điểm Thi";
            // 
            // txt_tenlop
            // 
            this.txt_tenlop.AutoSize = true;
            this.txt_tenlop.Location = new System.Drawing.Point(505, 96);
            this.txt_tenlop.Name = "txt_tenlop";
            this.txt_tenlop.Size = new System.Drawing.Size(61, 20);
            this.txt_tenlop.TabIndex = 18;
            this.txt_tenlop.Text = "Tên lớp";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Blue;
            this.label7.Location = new System.Drawing.Point(440, 96);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 20);
            this.label7.TabIndex = 17;
            this.label7.Text = "Lớp: ";
            // 
            // com_lop
            // 
            this.com_lop.FormattingEnabled = true;
            this.com_lop.Location = new System.Drawing.Point(509, 44);
            this.com_lop.Name = "com_lop";
            this.com_lop.Size = new System.Drawing.Size(175, 28);
            this.com_lop.TabIndex = 16;
            this.com_lop.SelectedIndexChanged += new System.EventHandler(this.com_lop_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(428, 52);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(56, 20);
            this.label8.TabIndex = 15;
            this.label8.Text = "Mã lớp";
            // 
            // txt_tenmh
            // 
            this.txt_tenmh.AutoSize = true;
            this.txt_tenmh.Location = new System.Drawing.Point(192, 187);
            this.txt_tenmh.Name = "txt_tenmh";
            this.txt_tenmh.Size = new System.Drawing.Size(101, 20);
            this.txt_tenmh.TabIndex = 14;
            this.txt_tenmh.Text = "Tên môn học";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Blue;
            this.label6.Location = new System.Drawing.Point(100, 187);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 20);
            this.label6.TabIndex = 13;
            this.label6.Text = "Tên môn:";
            // 
            // txt_tensinhvien
            // 
            this.txt_tensinhvien.AutoSize = true;
            this.txt_tensinhvien.Location = new System.Drawing.Point(192, 96);
            this.txt_tensinhvien.Name = "txt_tensinhvien";
            this.txt_tensinhvien.Size = new System.Drawing.Size(101, 20);
            this.txt_tensinhvien.TabIndex = 12;
            this.txt_tensinhvien.Text = "Tên sinh viên";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Blue;
            this.label5.Location = new System.Drawing.Point(136, 96);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 20);
            this.label5.TabIndex = 11;
            this.label5.Text = "SV: ";
            // 
            // com_mon
            // 
            this.com_mon.FormattingEnabled = true;
            this.com_mon.Location = new System.Drawing.Point(196, 135);
            this.com_mon.Name = "com_mon";
            this.com_mon.Size = new System.Drawing.Size(175, 28);
            this.com_mon.TabIndex = 6;
            this.com_mon.SelectedIndexChanged += new System.EventHandler(this.com_mon_SelectedIndexChanged);
            // 
            // com_masv
            // 
            this.com_masv.FormattingEnabled = true;
            this.com_masv.Location = new System.Drawing.Point(196, 44);
            this.com_masv.Name = "com_masv";
            this.com_masv.Size = new System.Drawing.Size(175, 28);
            this.com_masv.TabIndex = 5;
            this.com_masv.SelectedIndexChanged += new System.EventHandler(this.com_masv_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(84, 143);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Mã môn";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(80, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Mã sinh viên";
            // 
            // ds
            // 
            this.ds.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.ds.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ds.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.masv,
            this.mamh,
            this.malop,
            this.diemtb,
            this.tinhtrang,
            this.ghichu});
            this.ds.Location = new System.Drawing.Point(25, 311);
            this.ds.Name = "ds";
            this.ds.Size = new System.Drawing.Size(1053, 193);
            this.ds.TabIndex = 2;
            // 
            // masv
            // 
            this.masv.DataPropertyName = "masv";
            this.masv.HeaderText = "Mã sinh viên";
            this.masv.Name = "masv";
            // 
            // mamh
            // 
            this.mamh.DataPropertyName = "mamh";
            this.mamh.HeaderText = "Mã môn học";
            this.mamh.Name = "mamh";
            // 
            // malop
            // 
            this.malop.DataPropertyName = "malop";
            this.malop.HeaderText = "Mã lớp";
            this.malop.Name = "malop";
            // 
            // diemtb
            // 
            this.diemtb.DataPropertyName = "diemtb";
            this.diemtb.HeaderText = "Điểm TB";
            this.diemtb.Name = "diemtb";
            // 
            // tinhtrang
            // 
            this.tinhtrang.DataPropertyName = "tinhtrang";
            this.tinhtrang.HeaderText = "Tình Trạng";
            this.tinhtrang.Name = "tinhtrang";
            // 
            // ghichu
            // 
            this.ghichu.DataPropertyName = "ghichu";
            this.ghichu.HeaderText = "Ghi chú";
            this.ghichu.Name = "ghichu";
            // 
            // btn_them
            // 
            this.btn_them.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.btn_them.Appearance.Options.UseFont = true;
            this.btn_them.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("simpleButton1.ImageOptions.Image")));
            this.btn_them.ImageOptions.ImageToTextIndent = -10;
            this.btn_them.Location = new System.Drawing.Point(720, 173);
            this.btn_them.Margin = new System.Windows.Forms.Padding(50, 3, 3, 3);
            this.btn_them.Name = "btn_them";
            this.btn_them.Size = new System.Drawing.Size(121, 37);
            this.btn_them.TabIndex = 28;
            this.btn_them.Text = "Thêm";
            this.btn_them.Click += new System.EventHandler(this.btn_them_Click);
            // 
            // txt_ghichu
            // 
            this.txt_ghichu.Location = new System.Drawing.Point(812, 137);
            this.txt_ghichu.Name = "txt_ghichu";
            this.txt_ghichu.ReadOnly = true;
            this.txt_ghichu.Size = new System.Drawing.Size(160, 26);
            this.txt_ghichu.TabIndex = 30;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(716, 143);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(64, 20);
            this.label12.TabIndex = 29;
            this.label12.Text = "Ghi chú";
            // 
            // fr_ketqua
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1212, 692);
            this.Controls.Add(this.ds);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "fr_ketqua";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Kết quả sinh viên";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.fr_ketqua_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ds)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView ds;
        private System.Windows.Forms.DataGridViewTextBoxColumn masv;
        private System.Windows.Forms.DataGridViewTextBoxColumn mamh;
        private System.Windows.Forms.DataGridViewTextBoxColumn malop;
        private System.Windows.Forms.DataGridViewTextBoxColumn diemtb;
        private System.Windows.Forms.DataGridViewTextBoxColumn tinhtrang;
        private System.Windows.Forms.DataGridViewTextBoxColumn ghichu;
        private System.Windows.Forms.ComboBox com_mon;
        private System.Windows.Forms.ComboBox com_masv;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label txt_tensinhvien;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label txt_tenmh;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label txt_tenlop;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox com_lop;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_diemthi;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_diem;
        private System.Windows.Forms.Label label4;
        private DevExpress.XtraEditors.SimpleButton btn_capnhat;
        private System.Windows.Forms.TextBox txt_xeploai;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txt_diemtb;
        private System.Windows.Forms.Label label10;
        private DevExpress.XtraEditors.SimpleButton btn_them;
        private System.Windows.Forms.TextBox txt_ghichu;
        private System.Windows.Forms.Label label12;
    }
}