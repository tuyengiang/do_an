﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySinhVien
{
    public partial class frScreen : Form
    {
        public frScreen()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                processStart.Width += 1;
                if(processStart.Width>= 364)
                {
                    timer1.Stop();
                    this.Hide();
                    frLogin login = new frLogin();
                    login.Show();
                }
            }
            catch(Exception)
            {
                return;
            }
        }

        private void frScreen_Load(object sender, EventArgs e)
        {

        }
    }
}
