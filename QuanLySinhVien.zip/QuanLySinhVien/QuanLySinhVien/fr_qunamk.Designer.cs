﻿namespace QuanLySinhVien
{
    partial class fr_qunamk
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fr_qunamk));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_user = new System.Windows.Forms.TextBox();
            this.btn_thoat = new DevExpress.XtraEditors.SimpleButton();
            this.btn_cap_nhat = new DevExpress.XtraEditors.SimpleButton();
            this.txt_nhaplai = new System.Windows.Forms.TextBox();
            this.txt_password = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(133, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(304, 46);
            this.label1.TabIndex = 9;
            this.label1.Text = "Quên mật khẩu";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(108, 116);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(116, 20);
            this.label2.TabIndex = 10;
            this.label2.Text = "Tên đăng nhập";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(108, 172);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 20);
            this.label3.TabIndex = 11;
            this.label3.Text = "Mật khẩu mới";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(108, 224);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(136, 20);
            this.label4.TabIndex = 12;
            this.label4.Text = "Nhập lại mật khẩu";
            // 
            // txt_user
            // 
            this.txt_user.Location = new System.Drawing.Point(265, 109);
            this.txt_user.Name = "txt_user";
            this.txt_user.Size = new System.Drawing.Size(198, 26);
            this.txt_user.TabIndex = 13;
            // 
            // btn_thoat
            // 
            this.btn_thoat.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.btn_thoat.Appearance.Options.UseFont = true;
            this.btn_thoat.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_thoat.ImageOptions.Image")));
            this.btn_thoat.Location = new System.Drawing.Point(294, 280);
            this.btn_thoat.Name = "btn_thoat";
            this.btn_thoat.Size = new System.Drawing.Size(107, 39);
            this.btn_thoat.TabIndex = 17;
            this.btn_thoat.Text = "Thoát";
            this.btn_thoat.Click += new System.EventHandler(this.btn_thoat_Click);
            // 
            // btn_cap_nhat
            // 
            this.btn_cap_nhat.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.btn_cap_nhat.Appearance.Options.UseFont = true;
            this.btn_cap_nhat.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_cap_nhat.ImageOptions.Image")));
            this.btn_cap_nhat.Location = new System.Drawing.Point(150, 280);
            this.btn_cap_nhat.Name = "btn_cap_nhat";
            this.btn_cap_nhat.Size = new System.Drawing.Size(107, 39);
            this.btn_cap_nhat.TabIndex = 16;
            this.btn_cap_nhat.Text = "Cập nhật";
            this.btn_cap_nhat.Click += new System.EventHandler(this.btn_cap_nhat_Click);
            // 
            // txt_nhaplai
            // 
            this.txt_nhaplai.Location = new System.Drawing.Point(265, 218);
            this.txt_nhaplai.Name = "txt_nhaplai";
            this.txt_nhaplai.Size = new System.Drawing.Size(198, 26);
            this.txt_nhaplai.TabIndex = 15;
            this.txt_nhaplai.UseSystemPasswordChar = true;
            // 
            // txt_password
            // 
            this.txt_password.Location = new System.Drawing.Point(265, 166);
            this.txt_password.Name = "txt_password";
            this.txt_password.Size = new System.Drawing.Size(198, 26);
            this.txt_password.TabIndex = 14;
            this.txt_password.UseSystemPasswordChar = true;
            // 
            // fr_qunamk
            // 
            this.AcceptButton = this.btn_cap_nhat;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(571, 353);
            this.Controls.Add(this.btn_thoat);
            this.Controls.Add(this.btn_cap_nhat);
            this.Controls.Add(this.txt_nhaplai);
            this.Controls.Add(this.txt_password);
            this.Controls.Add(this.txt_user);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "fr_qunamk";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quên mật khẩu";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_user;
        private DevExpress.XtraEditors.SimpleButton btn_cap_nhat;
        private DevExpress.XtraEditors.SimpleButton btn_thoat;
        private System.Windows.Forms.TextBox txt_nhaplai;
        private System.Windows.Forms.TextBox txt_password;
    }
}