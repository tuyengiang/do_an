﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySinhVien
{
    public partial class fr_qunamk : Form
    {
        connectDB conn = new connectDB();
        public fr_qunamk()
        {
            InitializeComponent();
        }

        private void btn_thoat_Click(object sender, EventArgs e)
        {
            this.Close();
            frLogin f = new frLogin();
            f.Show();
        }
        private String ChangeMD5(String strSource)
        {
            System.Security.Cryptography.MD5CryptoServiceProvider x = new System.Security.Cryptography.MD5CryptoServiceProvider();//khởi tạo md5
            byte[] bs = System.Text.Encoding.UTF8.GetBytes(strSource);
            bs = x.ComputeHash(bs);
            System.Text.StringBuilder s = new System.Text.StringBuilder();
            foreach (Byte b in bs)
            {
                s.Append(b.ToString("X2").ToUpper());
            }
            return s.ToString();
        }
        private void btn_cap_nhat_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_user.Text == "")
                {
                    MessageBox.Show("Mời bạn nhập tên đăng nhập !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_user.Focus();
                }
                else if (txt_password.Text == "")
                {
                    MessageBox.Show("Mời bạn nhập mật khẩu !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_password.Focus();
                }
                else if (txt_nhaplai.Text == "")
                {
                    MessageBox.Show("Mời bạn nhập lại mật khẩu !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_nhaplai.Focus();
                }
                else
                {
                    String pass = txt_password.Text;
                    String pass1 = txt_nhaplai.Text;
                    if(pass.Length>=8 && pass1.Length >= 8)
                    {
                        if (txt_password.Text == txt_nhaplai.Text)
                        {
                            conn.Open();
                            string show = "select username from TKAdmin where username='" + txt_user.Text + "'";
                            SqlCommand cd = new SqlCommand(show, conn.Connect());
                            SqlDataAdapter da1 = new SqlDataAdapter(cd);
                            DataTable d1t = new DataTable();
                            da1.Fill(d1t);
                            conn.Close();

                            String username = "";
                            foreach (DataRow u in d1t.Rows)
                            {
                                username = u["username"].ToString();
                            }
                            if (txt_user.Text==username)
                            {
                                String passMD5 = ChangeMD5(txt_password.Text);
                                conn.Open();
                                string sql = "update TkAdmin set password='" + passMD5 + "' where username='" + txt_user.Text + "'";
                                conn.Excute(sql);
                                DialogResult f = MessageBox.Show("Cập nhật mật khẩu thành công. Bạn có muốn đăng nhập không ?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
                                if (f == DialogResult.Yes)
                                {
                                    this.Close();
                                    frLogin a = new frLogin();
                                    a.Show();

                                }

                            }
                            else
                            {
                                MessageBox.Show("Tài khoản không tồn tại. Mời nhập lại !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                txt_user.Clear();
                                txt_user.Focus();
                            }
                        }
                        else
                        {
                            MessageBox.Show("Mật khẩu bạn nhập không khớp. Mời nhập lại !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            txt_nhaplai.Clear();
                            txt_password.Clear();
                            txt_password.Focus();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Mật khẩu bạn nhập phải lớn hơn hoặc bằng 8 ký tự. Mời nhập lại !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        txt_nhaplai.Clear();
                        txt_password.Clear();
                        txt_password.Focus();
                    }
                }

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString(),"Lỗi",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }

        }
    }
}
