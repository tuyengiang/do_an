﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.Skins;
using DevExpress.UserSkins;

namespace QuanLySinhVien
{
    public partial class Begin : Form
    {

        public delegate void SendValue(string value);
        public SendValue Sender;

        public Begin()
        {
            InitializeComponent();
            Sender = new SendValue(GetValue);
        }
        String a = "";
        public void GetValue(string value)
        {
            String a= value;
        }
        private void treeList1_FocusedNodeChanged(object sender, DevExpress.XtraTreeList.FocusedNodeChangedEventArgs e)
        {

        }

        private void Begin_Load(object sender, EventArgs e)
        {
            DevExpress.UserSkins.BonusSkins.Register();
            DevExpress.UserSkins.OfficeSkins.Register();
            DevExpress.XtraBars.Helpers.SkinHelper.InitSkinGallery(skin_theme, true);
        }

        private void btn_doimk_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            hethong.changePassword p = new hethong.changePassword();
            p.MdiParent = this;
            p.Show();
        }

        private void btn_dsaccount_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            hethong.dsAccount p = new hethong.dsAccount();
            p.MdiParent = this;
            p.Show();
        }

        private void navBarControl1_Click(object sender, EventArgs e)
        {
            
        }

        private void btn_out_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            DialogResult f = MessageBox.Show("Bạn có muốn thoát không?", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (f == DialogResult.OK)
            {
                this.Close();
                frLogin login = new frLogin();
                login.Show();
            }
        }

        private void btn_thoat_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            DialogResult f = MessageBox.Show("Bạn muốn khóa phần mềm. Và quay lại màn hình đăng nhập?", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (f == DialogResult.OK)
            {
                this.Close();
                frLogin login = new frLogin();
                login.Show();
            }
        }

        private void ql_gv_LinkClicked(object sender, DevExpress.XtraNavBar.NavBarLinkEventArgs e)
        {
            QuanLy.ql_giaovien f= new QuanLy.ql_giaovien();
            f.MdiParent = this;
            f.Show();
        }

        private void ribbonControl1_Click(object sender, EventArgs e)
        {

        }

        private void ql_sinhvien_LinkClicked(object sender, DevExpress.XtraNavBar.NavBarLinkEventArgs e)
        {
            QuanLy.ql_sinhvien f = new QuanLy.ql_sinhvien();
            f.MdiParent = this;
            f.Show();
        }

        private void ql_khoa_LinkClicked(object sender, DevExpress.XtraNavBar.NavBarLinkEventArgs e)
        {
            QuanLy.ql_khoa f = new QuanLy.ql_khoa();
            f.MdiParent = this;
            f.Show();
        }

        private void ql_khoa_hoc_LinkClicked(object sender, DevExpress.XtraNavBar.NavBarLinkEventArgs e)
        {
            QuanLy.ql_khoahoc f= new QuanLy.ql_khoahoc();
            f.MdiParent = this;
            f.Show();
        }

        private void ql_lop_LinkClicked(object sender, DevExpress.XtraNavBar.NavBarLinkEventArgs e)
        {
            QuanLy.ql_lophoc f = new QuanLy.ql_lophoc();
            f.MdiParent = this;
            f.Show();
        }

        private void ql_mh_LinkClicked(object sender, DevExpress.XtraNavBar.NavBarLinkEventArgs e)
        {
            QuanLy.ql_monhoc f = new QuanLy.ql_monhoc();
            f.MdiParent = this;
            f.Show();
        }

        private void tk_gv_LinkClicked(object sender, DevExpress.XtraNavBar.NavBarLinkEventArgs e)
        {
            TimKiem.tk_giaovien f = new TimKiem.tk_giaovien();
            f.MdiParent = this;
            f.Show();
        }

        private void tk_sv_LinkClicked(object sender, DevExpress.XtraNavBar.NavBarLinkEventArgs e)
        {
            TimKiem.tk_sinhvien f = new TimKiem.tk_sinhvien();
            f.MdiParent = this;
            f.Show();
        }

        private void tk_khoa_LinkClicked(object sender, DevExpress.XtraNavBar.NavBarLinkEventArgs e)
        {
            TimKiem.tk_khoa f = new TimKiem.tk_khoa();
            f.MdiParent = this;
            f.Show();
        }

        private void tk_khoahoc_LinkClicked(object sender, DevExpress.XtraNavBar.NavBarLinkEventArgs e)
        {
            TimKiem.tk_khoahoc f = new TimKiem.tk_khoahoc();
            f.MdiParent = this;
            f.Show();
        }

        private void tk_lop_LinkClicked(object sender, DevExpress.XtraNavBar.NavBarLinkEventArgs e)
        {
            TimKiem.tk_lophoc f = new TimKiem.tk_lophoc();
            f.MdiParent = this;
            f.Show();
        }

        private void tk_monhoc_LinkClicked(object sender, DevExpress.XtraNavBar.NavBarLinkEventArgs e)
        {
            TimKiem.tk_monhoc f = new TimKiem.tk_monhoc();
            f.MdiParent = this;
            f.Show();
        }

        private void tk_diem_LinkClicked(object sender, DevExpress.XtraNavBar.NavBarLinkEventArgs e)
        {
            TimKiem.tk_diem f = new TimKiem.tk_diem();
            f.MdiParent = this;
            f.Show();
        }

        private void ds_diem_LinkClicked(object sender, DevExpress.XtraNavBar.NavBarLinkEventArgs e)
        {
            QuanLy.ql_nhapdiem f = new QuanLy.ql_nhapdiem();
            f.MdiParent = this;
            f.Show();
        }

        private void nav_small_ketquahoc_LinkClicked(object sender, DevExpress.XtraNavBar.NavBarLinkEventArgs e)
        {
            ThongKe.fr_ketqua f = new ThongKe.fr_ketqua();
            f.MdiParent = this;
            f.Show();
        }

        private void btn_k_LinkClicked(object sender, DevExpress.XtraNavBar.NavBarLinkEventArgs e)
        {
            ThongKe.fr_baocao f = new ThongKe.fr_baocao();
            f.MdiParent = this;
            f.Show();
        }

        private void cmd_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            System.Diagnostics.Process.Start("C:\\Windows\\System32\\cmd.exe");
        }

        private void word_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            MessageBox.Show("Tính năng đang xây dựng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        private void excel_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            MessageBox.Show("Tính năng đang xây dựng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        private void btn_info_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            hethong.info_form f = new hethong.info_form();
            f.MdiParent = this;
            f.Show();
        }

        private void ql_he_LinkClicked(object sender, DevExpress.XtraNavBar.NavBarLinkEventArgs e)
        {
            QuanLy.ql_he f = new QuanLy.ql_he();
            f.MdiParent = this;
            f.Show();
        }

        private void update_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            MessageBox.Show("Phần mềm bạn đang dùng là phiên bản mới nhất !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        private void tk_ketqua_LinkClicked(object sender, DevExpress.XtraNavBar.NavBarLinkEventArgs e)
        {
            TimKiem.tk_ketqua f = new TimKiem.tk_ketqua();
            f.MdiParent = this;
            f.Show();
        }
    }
}
