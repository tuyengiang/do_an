﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace QuanLySinhVien
{
    public partial class frRegister : Form
    {
        connectDB conn = new connectDB();
        public frRegister()
        {
            InitializeComponent();
        }
        private String ChangeMD5(String strSource)
        {
            System.Security.Cryptography.MD5CryptoServiceProvider x = new System.Security.Cryptography.MD5CryptoServiceProvider();//khởi tạo md5
            byte[] bs = System.Text.Encoding.UTF8.GetBytes(strSource);
            bs = x.ComputeHash(bs);
            System.Text.StringBuilder s = new System.Text.StringBuilder();
            foreach (Byte b in bs)
            {
                s.Append(b.ToString("X2").ToUpper());
            }
            return s.ToString();
        }
        private void btn_thoat_Click(object sender, EventArgs e)
        {
           
        }

        private void btn_register_Click(object sender, EventArgs e)
        {
            


        }

        private void btn_register_Click_1(object sender, EventArgs e)
        {
            try
            {
                String username = txt_username.Text;
                String password = txt_password.Text;
                String password_new = txt_password_new.Text;

                if (username == "")
                {
                    MessageBox.Show("Bạn chưa nhập tên đăng nhập !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Question);
                    txt_username.Focus();
                }
                else if (password == "" || password_new == "")
                {
                    MessageBox.Show("Bạn chưa nhập mật khẩu !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Question);
                    txt_password.Focus();
                }
                else
                {
                    if (password == password_new)
                    {
                        String admin = "SELECT username FROM TKAdmin WHERE username='" + username + "'";
                        SqlCommand cmd1 = new SqlCommand(admin, conn.Connect());
                        SqlDataAdapter da = new SqlDataAdapter(cmd1);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        String user_c = "";
                        foreach (DataRow TKAmin in dt.Rows)
                        {
                            user_c = TKAmin["username"].ToString();
                        }
                        if (username == user_c)
                        {
                            MessageBox.Show("Tài khoản đã được đăng ký! Mời nhập lại !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            txt_username.Clear();
                            txt_password.Clear();
                            txt_password_new.Clear();
                            txt_username.Focus();
                        }
                        else
                        {
                            if (password.Length >= 8 && password_new.Length >= 8)
                            {
                                String passMd5 = ChangeMD5(txt_password.Text);
                                conn.Open();
                                string sql = "insert into TKAdmin (username,password,status)"
                                    + "values('" + username + "','" + passMd5 + "',5)";
                                conn.Excute(sql);
                                DialogResult f = MessageBox.Show("Đăng ký thành công !!! Bạn muốn đăng nhập không ?", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Asterisk);
                                if (f == DialogResult.OK)
                                {
                                    this.Hide();
                                    frLogin login = new frLogin();
                                    login.Show();
                                }
                                txt_username.Clear();
                                txt_password.Clear();
                                txt_password_new.Clear();
                                txt_username.Focus();
                            }
                            else
                            {
                                MessageBox.Show("Mật khẩu bạn nhập phải lớn hơn hoặc bằng 8 ký tự !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                txt_password.Clear();
                                txt_password_new.Clear();
                                txt_password.Focus();
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("Mật khẩu bạn nhập không khớp !!! Mời nhập lại !", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Question);
                        txt_password.Clear();
                        txt_password_new.Clear();
                        txt_password.Focus();
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Đã có lỗi sảy ra", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                MessageBox.Show(ex.ToString());
            }
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            frLogin login = new frLogin();
            login.Show();
            this.Hide();
        }

        private void frRegister_Load(object sender, EventArgs e)
        {

        }
    }
}
