﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySinhVien.hethong
{
    public partial class changePassword : Form
    {
        connectDB conn = new connectDB();
        public delegate void SendValue(string value);
        public SendValue Sender;

        public changePassword()
        {
            InitializeComponent();
        }

        
        public void GetValue(string value)
        {
            txt_user.Text = value;
        }
        private void btn_thoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private String ChangeMD5(String strSource)
        {
            System.Security.Cryptography.MD5CryptoServiceProvider x = new System.Security.Cryptography.MD5CryptoServiceProvider();//khởi tạo md5
            byte[] bs = System.Text.Encoding.UTF8.GetBytes(strSource);
            bs = x.ComputeHash(bs);
            System.Text.StringBuilder s = new System.Text.StringBuilder();
            foreach (Byte b in bs)
            {
                s.Append(b.ToString("X2").ToUpper());
            }
            return s.ToString();
        }
        private void btn_doi_Click(object sender, EventArgs e)
        {
           
        }

        private void btn_doi_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (txt_user.Text == "")
                {
                    MessageBox.Show("Mời nhập tên tài khoản !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    txt_user.Focus();
                }
                else if (txt_pass_cu.Text == "")
                {
                    MessageBox.Show("Mời nhập mật khẩu cũ !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    txt_user.Focus();
                }
                else if (txt_passmoi.Text == "")
                {
                    MessageBox.Show("Mời nhập mật khẩu mới !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    txt_user.Focus();
                }
                else if (txt_pass_new.Text == "")
                {
                    MessageBox.Show("Mời nhập mật khẩu mới !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    txt_user.Focus();
                }
                else
                {
                    String pass1 = txt_passmoi.Text;
                    String pass2 = txt_pass_new.Text;
                    if (pass1 == pass2)
                    {
                        if (pass1.Length >= 8)
                        {

                            conn.Open();
                            String show = "SELECT username,password FROM TKAdmin WHERE username='" + txt_user.Text + "'";
                            SqlCommand c = new SqlCommand(show, conn.Connect());
                            SqlDataAdapter d = new SqlDataAdapter(c);
                            DataTable d1 = new DataTable();
                            d.Fill(d1);
                            conn.Close();
                            String user = "";
                            String pass = "";
                            foreach (DataRow ds in d1.Rows)
                            {
                                user = ds["username"].ToString();
                                pass = ds["password"].ToString();

                            }
                            String passMD5 = ChangeMD5(txt_pass_cu.Text);
                            if (txt_user.Text == user && passMD5 == pass)
                            {
                                conn.Open();
                                String passcd = ChangeMD5(txt_passmoi.Text);
                                String sql = "UPDATE TKAdmin SET password='" + ChangeMD5(txt_passmoi.Text) + "' WHERE username='" + txt_user.Text + "'";
                                conn.Excute(sql);
                                DialogResult f = MessageBox.Show("Đổi mật khẩu thành công. Bạn có muốn đăng nhập lại không ?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                                if (f == DialogResult.Yes)
                                {
                                    this.Close();
                                    Begin begin = new Begin();
                                    begin.Visible = false;
                                    frLogin login = new frLogin();
                                    login.Show();

                                }

                            }
                            else
                            {
                                MessageBox.Show("Tài khoản và mật khảu không đúng !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                txt_pass_cu.Clear();
                                txt_user.Clear();
                                txt_user.Focus();
                            }

                        }
                        else
                        {
                            MessageBox.Show("Mật khẩu bạn nhập phải lớn hơn hoặc  8 ksy tự !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            txt_passmoi.Clear();
                            txt_pass_new.Clear();
                            txt_passmoi.Focus();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Mật khẩu bạn nhập không trùng nhau. Mời nhập lại !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txt_passmoi.Clear();
                        txt_pass_new.Clear();
                        txt_passmoi.Focus();
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Thông báo", MessageBoxButtons.OK);
            }
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void changePassword_Load(object sender, EventArgs e)
        {

        }
    }
}
