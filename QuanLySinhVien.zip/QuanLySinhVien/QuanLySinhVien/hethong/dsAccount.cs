﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace QuanLySinhVien.hethong
{
    public partial class dsAccount : Form
    {
        connectDB conn = new connectDB();
        public void hienthi()
        {
            conn.Open();
            String sql = "SELECT * FROM TKAdmin";
            SqlCommand cmd = new SqlCommand(sql, conn.Connect());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            conn.Close();
            ds.DataSource = dt;

        }

        public void Clear()
        {
            txt_password.Clear();
            txt_username.Clear();
            com_status.Text = "";
            txt_username.Focus();
        }
        public void Execute(String sql,String Ms)
        {
            try
            {
                String user = txt_username.Text;
                String pass = txt_password.Text;
                String com = com_status.Text;
                if (user == "")
                {
                    MessageBox.Show("Bạn chưa nhập tên đăng nhập !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Question);
                    txt_username.Focus();
                }
                else if (pass == "")
                {
                    MessageBox.Show("Bạn chưa nhập mật khẩu !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Question);
                    txt_password.Focus();
                }
                else if (com == "")
                {
                    MessageBox.Show("Bạn chưa chọn trang thái !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Question);
                }
                else
                {
                    // lay thong tin user trong csdl
                    conn.Open();
                    String show = "SELECT * FROM TKAdmin WHERE username='" + user + "'";
                    SqlCommand c = new SqlCommand(show, conn.Connect());
                    SqlDataAdapter da1 = new SqlDataAdapter(c);
                    DataTable dt1 = new DataTable();
                    da1.Fill(dt1);
                    conn.Close();
                    String user_check = "";
                    foreach(DataRow s in dt1.Rows)
                    {
                        user_check = s["username"].ToString();
                    }

                    /***thuc hien truy vẫn insert,update**/

                    if (user != user_check)
                    {
                        if (txt_password.Text.Length >= 8)
                        {
                            conn.Open();
                            String sql1 = sql;
                            conn.Excute(sql1);
                            MessageBox.Show(Ms, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            hienthi();
                            Clear();
                        }
                        else
                        {
                            MessageBox.Show("Mật khẩu phả lớn hơn 8 ký tự !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

                            txt_password.Clear();
                            txt_password.Focus();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Tài khoản đã có !!! Mời nhập lại !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                      
                        txt_username.Clear();
                        txt_username.Focus();
                    }

                }
            }catch(Exception e)
            {
                MessageBox.Show(e.ToString(), "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public dsAccount()
        {
            InitializeComponent();
        }

        private void dsAccount_Load(object sender, EventArgs e)
        {
            hienthi();
            this.ds.DefaultCellStyle.Font = new Font("", 15);
        }

        private String ChangeMD5(String strSource)
        {
            System.Security.Cryptography.MD5CryptoServiceProvider x = new System.Security.Cryptography.MD5CryptoServiceProvider();//khởi tạo md5
            byte[] bs = System.Text.Encoding.UTF8.GetBytes(strSource);
            bs = x.ComputeHash(bs);
            System.Text.StringBuilder s = new System.Text.StringBuilder();
            foreach (Byte b in bs)
            {
                s.Append(b.ToString("X2").ToUpper());
            }
            return s.ToString();
        }
        private void btn_add_Click(object sender, EventArgs e)
        {
            
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void ds_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                
                int numrow;
                numrow = e.RowIndex;
                txt_username.Text = ds.Rows[numrow].Cells[0].Value.ToString();
                string pass = ChangeMD5(ds.Rows[numrow].Cells[1].Value.ToString());
                txt_password.Text =pass;
                String cv = "";
                int status = Int32.Parse(ds.Rows[numrow].Cells[2].Value.ToString());
                if (status == 1)
                {
                    cv = "Quản trị viên";
                }
                if (status == 2)
                {
                    cv = "Giáo vụ";
                }
                if (status == 3)
                {
                    cv = "Kế toán";
                }
                if (status == 4)
                {
                    cv = "Giáo viên";
                }
                if (status == 5)
                {
                    cv = "Sinh viên";
                }
                com_status.Text= cv.ToString();
                
            }
            catch
            {
                MessageBox.Show("Mời bạn click vào danh sách", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

        }

        private void btn_edit_Click(object sender, EventArgs e)
        {
           
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            
        }

        private void btn_add_Click_1(object sender, EventArgs e)
        {
            String ms = "Thêm tài khoản thành công !!!";
            String com = com_status.Text;
            int status = 5;
            if (com == "Quản trị viên")
            {
                status = 1;
            }
            if (com == "Giáo vụ")
            {
                status = 2;
            }
            if (com == "Kế toán")
            {
                status = 3;
            }
            if (com == "Giáo viên")
            {
                status = 4;
            }
            if (com == "Sinh viên")
            {
                status = 5;
            }
            String passMD5 = ChangeMD5(txt_password.Text);
            String sql = "INSERT INTO TKAdmin (username,password,status)" +
                "VALUES('" + txt_username.Text + "','" + passMD5 + "','" + status + "')";
            Execute(sql, ms);
        }

        private void btn_edit_Click_1(object sender, EventArgs e)
        {
            try
            {
                String ms = "Sửa tài khoản thành công !!!";
                String com = com_status.Text;
                int status = 5;
                if (com == "Quản trị viên")
                {
                    status = 1;
                }
                if (com == "Giáo vụ")
                {
                    status = 2;
                }
                if (com == "Kế toán")
                {
                    status = 3;
                }
                if (com == "Giáo viên")
                {
                    status = 4;
                }
                if (com == "Sinh viên")
                {
                    status = 5;
                }

                if (txt_password.Text.Length >= 8)
                {
                    conn.Open();
                    String update = "UPDATE TKAdmin SET password='" + ChangeMD5(txt_password.Text) + "',status='" + status + "' WHERE username='" + txt_username.Text + "'";
                    conn.Excute(update);
                    MessageBox.Show(ms, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    hienthi();
                    Clear();
                }
                else
                {
                    MessageBox.Show("Mật khẩu phả lớn hơn 8 ký tự !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

                    txt_password.Clear();
                    txt_password.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_delete_Click_1(object sender, EventArgs e)
        {
            try
            {
                String ms = "Xóa tài khoản thành công !!!";
                DialogResult f = MessageBox.Show("Bạn muốn xóa tài khoản này không ?", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (f == DialogResult.OK)
                {
                    conn.Open();
                    String delete = "DELETE FROM TKAdmin WHERE username='" + txt_username.Text + "'";
                    conn.Excute(delete);
                    MessageBox.Show(ms, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    hienthi();
                    Clear();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
