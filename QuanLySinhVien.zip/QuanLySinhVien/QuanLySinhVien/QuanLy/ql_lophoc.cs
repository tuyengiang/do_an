﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySinhVien.QuanLy
{
    public partial class ql_lophoc : Form
    {
        connectDB conn = new connectDB();
        public void hienthi()
        {
            String sql = "SELECT * FROM LOP";
            SqlCommand cmd = new SqlCommand(sql, conn.Connect());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            ds.DataSource = dt;
        }
        public void loadcombobox()
        {
            conn.Open();
            string sql = "select makhoa,tenkhoa from KHOA";
            SqlCommand cmd = new SqlCommand(sql, conn.Connect());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet set = new DataSet();
            da.Fill(set, "Chọn khoa");
            com_khoa.DataSource = set.Tables[0];
            com_khoa.DisplayMember = "makhoa";
            com_khoa.ValueMember = "makhoa";
            conn.Close();

        }

        public void show_com(String txt)
        {
            string sql1 = "select tenkhoa from KHOA where makhoa='" + txt.ToString() + "'";
            SqlCommand cmd1 = new SqlCommand(sql1, conn.Connect());
            SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
            DataTable dt1 = new DataTable();
            da1.Fill(dt1);
            String khoa = "";
            foreach (DataRow r in dt1.Rows)
            {
                khoa = r["tenkhoa"].ToString();
            }
            txt_tenkhoa.Text = khoa.ToString();

        }
        public ql_lophoc()
        {
            InitializeComponent();
        }

        private void txt_tenhe_Click(object sender, EventArgs e)
        {

        }

        private void ql_lophoc_Load(object sender, EventArgs e)
        {
            hienthi();
            this.loadcombobox();
            String text = com_khoa.Text;
            this.show_com(text);

        }

        private void com_khoa_SelectedIndexChanged(object sender, EventArgs e)
        {
            String text = com_khoa.Text;
            this.show_com(text);
        }

        private void btn_them_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_malop.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập mã lớp !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_malop.Focus();
                }
                else if (txt_tenlop.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập tên lớp !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_tenlop.Focus();
                }
                else if (com_khoa.Text == "")
                {
                    MessageBox.Show("Bạn chưa chọn mã khoa !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    com_khoa.Focus();
                }
                else if (txt_ghichu.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập ghi chú !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_ghichu.Focus();
                }
                else
                {
                    // xuat dl
                    conn.Open();
                    string show = "select malop from LOP where malop='" + txt_malop.Text + "'";
                    SqlCommand c = new SqlCommand(show, conn.Connect());
                    SqlDataAdapter d = new SqlDataAdapter(c);
                    DataTable dt1 = new DataTable();
                    d.Fill(dt1);
                    conn.Close();
                    String malop = "";
                    foreach (DataRow r in dt1.Rows)
                    {
                        malop = r["malop"].ToString();
                    }

                    if (txt_malop.Text == malop)
                    {
                        MessageBox.Show("Mã lớp đã tồn tại. Mời bạn nhập lại !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        txt_malop.Clear();
                        txt_malop.Focus();
                    }
                    else
                    {
                        conn.Open();
                        string sql = "insert into LOP (malop,tenlop,makhoa,ghichu)"
                            + "values('" + txt_malop.Text + "',N'" + txt_tenlop.Text + "','" + com_khoa.Text + "',N'" + txt_ghichu.Text + "')";
                        conn.Excute(sql);
                        MessageBox.Show("Thêm lớp thành công !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        hienthi();
                        txt_malop.Clear(); txt_tenlop.Clear(); txt_ghichu.Clear();
                        com_khoa.Text = "";
                        txt_malop.Focus();

                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_sua_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_malop.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập mã lớp !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_malop.Focus();
                }
                else if (txt_tenlop.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập tên lớp !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_tenlop.Focus();
                }
                else if (com_khoa.Text == "")
                {
                    MessageBox.Show("Bạn chưa chọn mã khoa !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    com_khoa.Focus();
                }
                else if (txt_ghichu.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập ghi chú !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_ghichu.Focus();
                }
                else
                {
                    // xuat dl
                    conn.Open();
                    string show = "select malop from LOP where malop='" + txt_malop.Text + "'";
                    SqlCommand c = new SqlCommand(show, conn.Connect());
                    SqlDataAdapter d = new SqlDataAdapter(c);
                    DataTable dt1 = new DataTable();
                    d.Fill(dt1);
                    conn.Close();
                    String malop = "";
                    foreach (DataRow r in dt1.Rows)
                    {
                        malop = r["malop"].ToString();
                    }

                    if (txt_malop.Text != malop)
                    {
                        MessageBox.Show("Mã lớp không có !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        txt_malop.Clear();
                        txt_malop.Focus();
                    }
                    else
                    {
                        conn.Open();
                        string sql = "update LOP set malop='" + txt_malop.Text + "',tenlop=N'" + txt_tenlop.Text + "',makhoa='" + com_khoa.Text + "',ghichu=N'" + txt_ghichu.Text + "' where malop='" + txt_malop.Text + "'";
                        conn.Excute(sql);
                        MessageBox.Show("Sửa lớp thành công !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        hienthi();
                        txt_malop.Clear(); txt_tenlop.Clear(); txt_ghichu.Clear();
                        com_khoa.Text = "";
                        txt_malop.Focus();

                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_xoa_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_malop.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập mã lớp !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_malop.Focus();
                }
                else if (txt_tenlop.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập tên lớp !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_tenlop.Focus();
                }
                else if (com_khoa.Text == "")
                {
                    MessageBox.Show("Bạn chưa chọn mã khoa !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    com_khoa.Focus();
                }
                
                else
                {
                    // xuat dl
                    conn.Open();
                    string show = "select malop from LOP where malop='" + txt_malop.Text + "'";
                    SqlCommand c = new SqlCommand(show, conn.Connect());
                    SqlDataAdapter d = new SqlDataAdapter(c);
                    DataTable dt1 = new DataTable();
                    d.Fill(dt1);
                    conn.Close();
                    String malop = "";
                    foreach (DataRow r in dt1.Rows)
                    {
                        malop = r["malop"].ToString();
                    }

                    if (txt_malop.Text != malop)
                    {
                        MessageBox.Show("Mã lớp không có !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        txt_malop.Clear();
                        txt_malop.Focus();
                    }
                    else
                    {
                        DialogResult f = MessageBox.Show("Bạn muốn xóa lớp học không ?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (f == DialogResult.Yes)
                        {
                            conn.Open();
                            string sql = "delete from LOP  where malop='" + txt_malop.Text + "'";
                            conn.Excute(sql);
                            MessageBox.Show("Xóa lớp thành công !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            hienthi();
                            txt_malop.Clear(); txt_tenlop.Clear(); txt_ghichu.Clear();
                            com_khoa.Text = "";
                            txt_malop.Focus();
                        }

                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ds_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int number;
                number = e.RowIndex;
                txt_malop.Text = ds.Rows[number].Cells[0].Value.ToString();
                txt_tenlop.Text = ds.Rows[number].Cells[1].Value.ToString();
                com_khoa.Text = ds.Rows[number].Cells[2].Value.ToString();
                txt_ghichu.Text = ds.Rows[number].Cells[3].Value.ToString();
            }
            catch
            {
                MessageBox.Show("Mời bạn click vào danh sách để show form !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

        }
    }
}
