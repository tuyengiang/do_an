﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySinhVien.QuanLy
{
    public partial class ql_sinhvien : Form
    {
        connectDB conn = new connectDB();
        public void hienthi()
        {
            String sql = "SELECT * FROM SINHVIEN";
            SqlCommand cmd = new SqlCommand(sql, conn.Connect());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            ds.DataSource = dt;
        }
        public void loadcombobox_khoa()
        {
            conn.Open();
            string sql = "select makhoa from KHOA";
            SqlCommand cmd = new SqlCommand(sql, conn.Connect());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet set = new DataSet();
            da.Fill(set, "Chọn khoa");
            com_khoa.DataSource = set.Tables[0];
            com_khoa.DisplayMember = "makhoa";
            com_khoa.ValueMember = "makhoa";
            conn.Close();

        }
        public void loadcombobox_lop()
        {
            conn.Open();
            string sql = "select malop from LOP";
            SqlCommand cmd = new SqlCommand(sql, conn.Connect());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet set = new DataSet();
            da.Fill(set, "Chọn khoa");
            com_lop.DataSource = set.Tables[0];
            com_lop.DisplayMember = "malop";
            com_lop.ValueMember = "malop";
            conn.Close();

        }


        public void show_lop(String txt)
        {
            string sql1 = "select tenlop from LOP where malop='" + txt.ToString() + "'";
            SqlCommand cmd1 = new SqlCommand(sql1, conn.Connect());
            SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
            DataTable dt1 = new DataTable();
            da1.Fill(dt1);
            String lop = "";
            foreach (DataRow r in dt1.Rows)
            {
                lop = r["tenlop"].ToString();
            }
            txt_tenlop.Text = lop.ToString();

        }
        public void show_khoa(String txt)
        {
            string sql1 = "select tenkhoa from KHOA where makhoa='" + txt.ToString() + "'";
            SqlCommand cmd1 = new SqlCommand(sql1, conn.Connect());
            SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
            DataTable dt1 = new DataTable();
            da1.Fill(dt1);
            String khoa = "";
            foreach (DataRow r in dt1.Rows)
            {
                khoa = r["tenkhoa"].ToString();
            }
            txt_tenkhoa.Text = khoa.ToString();

        }

       
        public ql_sinhvien()
        {
            InitializeComponent();
        }

        private void ql_sinhvien_Load(object sender, EventArgs e)
        {
            hienthi();
            this.loadcombobox_khoa();
            this.loadcombobox_lop();
            ra_nam.Checked = true;

        }

        private void com_lop_SelectedIndexChanged(object sender, EventArgs e)
        {
            String lop = com_lop.Text;
            show_lop(lop);
        }

        private void com_khoa_SelectedIndexChanged(object sender, EventArgs e)
        {
            string khoa = com_khoa.Text;
            show_khoa(khoa);
        }

        private void btn_them_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_masv.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập mã sinh viên !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_masv.Focus();
                }
                else if (txt_tensv.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập tên sinh viên !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_tensv.Focus();
                }
                else if (com_lop.Text == "")
                {
                    MessageBox.Show("Bạn chưa chọn mã lớp !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    com_lop.Focus();
                }
                else if (com_khoa.Text == "")
                {
                    MessageBox.Show("Bạn chưa chọn mã khoa !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    com_khoa.Focus();
                }
                else if (txt_diachi.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập địa chỉ sinh viên !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_diachi.Focus();
                }
                else if (txt_ghichu.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập ghi chú sinh viên !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_ghichu.Focus();
                }
                else
                {
                    /// lay du lieu

                    conn.Open();
                    String out_put="select * from SINHVIEN where masv='"+txt_masv.Text+"'";
                    SqlCommand cmd1 = new SqlCommand(out_put, conn.Connect());
                    SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
                    DataTable dt1=new DataTable();
                    da1.Fill(dt1);
                    conn.Close();

                    String masv = "";
                    foreach(DataRow d in dt1.Rows)
                    {
                        masv = d["masv"].ToString();
                    }

                    if (masv == txt_masv.Text)
                    {
                        MessageBox.Show("Mã sinh viên bạn nhập đã tồn tại. Mời nhập lại !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        txt_masv.Clear();
                        txt_masv.Focus();
                    }
                    else
                    {

                        string gioitinh = "";
                        if (ra_nam.Checked == true)
                        {
                            gioitinh = "Nam";
                        }
                        else
                        {
                            gioitinh = "Nữ";
                        }
                        conn.Open();
                        String sql = "insert into SINHVIEN (masv,tensv,ngaysinh,gioitinh,diachi,malop,makhoa,sdt,ghichu)" +
                            "values('"+txt_masv.Text+ "',N'" + txt_tensv.Text + "','" + date_time.Text + "',N'" + gioitinh + "',N'" + txt_diachi.Text + "','" + com_lop.Text + "','" + com_khoa.Text + "','" + txt_sdt.Text + "',N'" + txt_ghichu.Text + "')";
                        conn.Excute(sql);
                        MessageBox.Show("Thêm sinh viên thành công !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        hienthi();
                        txt_masv.Clear(); txt_tensv.Clear(); txt_diachi.Clear();com_lop.Text = "";com_khoa.Text = "";txt_ghichu.Clear();
                        txt_masv.Focus();
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void btn_sua_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_masv.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập mã sinh viên !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_masv.Focus();
                }
                else if (txt_tensv.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập tên sinh viên !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_tensv.Focus();
                }
                else if (com_lop.Text == "")
                {
                    MessageBox.Show("Bạn chưa chọn mã lớp !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    com_lop.Focus();
                }
                else if (com_khoa.Text == "")
                {
                    MessageBox.Show("Bạn chưa chọn mã khoa !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    com_khoa.Focus();
                }
                else if (txt_diachi.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập địa chỉ sinh viên !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_diachi.Focus();
                }
                else if (txt_ghichu.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập ghi chú sinh viên !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_ghichu.Focus();
                }
                else
                {
                    /// lay du lieu

                    conn.Open();
                    String out_put = "select * from SINHVIEN where masv='" + txt_masv.Text + "'";
                    SqlCommand cmd1 = new SqlCommand(out_put, conn.Connect());
                    SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
                    DataTable dt1 = new DataTable();
                    da1.Fill(dt1);
                    conn.Close();

                    String masv = "";
                    foreach (DataRow d in dt1.Rows)
                    {
                        masv = d["masv"].ToString();
                    }

                    if (masv != txt_masv.Text)
                    {
                        MessageBox.Show("Mã sinh viên không tồn tại !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        txt_masv.Clear();
                        txt_masv.Focus();
                    }
                    else
                    {

                        string gioitinh = "";
                        if (ra_nam.Checked == true)
                        {
                            gioitinh = "Nam";
                        }
                        else
                        {
                            gioitinh = "Nữ";
                        }
                        conn.Open();
                        String sql = "update SINHVIEN set masv='" + txt_masv.Text + "',tensv=N'" + txt_tensv.Text + "',ngaysinh='" + date_time.Text + "',gioitinh=N'" + gioitinh + "',diachi=N'" + txt_diachi.Text + "',malop='" + com_lop.Text + "',makhoa='" + com_khoa.Text + "',sdt='" + txt_sdt.Text + "',ghichu=N'" + txt_ghichu.Text + "' where masv='" + txt_masv.Text + "'";
                        conn.Excute(sql);
                        MessageBox.Show("Sửa sinh viên thành công !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        hienthi();
                        txt_masv.Clear(); txt_tensv.Clear(); txt_diachi.Clear(); com_lop.Text = ""; com_khoa.Text = ""; txt_ghichu.Clear();
                        txt_masv.Focus();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ds_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int number;
                number = e.RowIndex;
                txt_masv.Text = ds.Rows[number].Cells[0].Value.ToString();
                txt_tensv.Text = ds.Rows[number].Cells[1].Value.ToString();
                date_time.Text = ds.Rows[number].Cells[2].Value.ToString();
                String gioitinh = ds.Rows[number].Cells[3].Value.ToString();
                if (gioitinh == "Nam")
                {
                    ra_nam.Checked = true;
                }
                else
                {
                    ra_nu.Checked = true;
                }

                txt_diachi.Text = ds.Rows[number].Cells[4].Value.ToString();
                com_lop.Text = ds.Rows[number].Cells[5].Value.ToString();
                com_khoa.Text = ds.Rows[number].Cells[6].Value.ToString();
                txt_sdt.Text = ds.Rows[number].Cells[7].Value.ToString();
                txt_ghichu.Text = ds.Rows[number].Cells[8].Value.ToString();
            }
            catch
            {
                MessageBox.Show("Mời bạn click vào danh sách để show form !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void btn_xoa_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_masv.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập mã sinh viên !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_masv.Focus();
                }
                else if (txt_tensv.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập tên sinh viên !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_tensv.Focus();
                }
                else if (com_lop.Text == "")
                {
                    MessageBox.Show("Bạn chưa chọn mã lớp !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    com_lop.Focus();
                }
                else if (com_khoa.Text == "")
                {
                    MessageBox.Show("Bạn chưa chọn mã khoa !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    com_khoa.Focus();
                }
                else if (txt_diachi.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập địa chỉ sinh viên !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_diachi.Focus();
                }
                else
                {
                    /// lay du lieu

                    conn.Open();
                    String out_put = "select * from SINHVIEN where masv='" + txt_masv.Text + "'";
                    SqlCommand cmd1 = new SqlCommand(out_put, conn.Connect());
                    SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
                    DataTable dt1 = new DataTable();
                    da1.Fill(dt1);
                    conn.Close();

                    String masv = "";
                    foreach (DataRow d in dt1.Rows)
                    {
                        masv = d["masv"].ToString();
                    }

                    if (masv != txt_masv.Text)
                    {
                        MessageBox.Show("Mã sinh viên không tồn tại !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        txt_masv.Clear();
                        txt_masv.Focus();
                    }
                    else
                    {

                        string gioitinh = "";
                        if (ra_nam.Checked == true)
                        {
                            gioitinh = "Nam";
                        }
                        else
                        {
                            gioitinh = "Nữ";
                        }
                        DialogResult f = MessageBox.Show("Bạn muốn xóa sinh viên không ?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (f == DialogResult.Yes)
                        {
                            conn.Open();
                            String sql = "delete from SINHVIEN where masv='" + txt_masv.Text + "'";
                            conn.Excute(sql);
                            MessageBox.Show("Xóa sinh viên thành công !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            hienthi();
                            txt_masv.Clear(); txt_tensv.Clear(); txt_diachi.Clear(); com_lop.Text = ""; com_khoa.Text = ""; txt_ghichu.Clear();
                            txt_masv.Focus();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
