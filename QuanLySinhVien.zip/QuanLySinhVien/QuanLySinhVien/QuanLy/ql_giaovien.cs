﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySinhVien.QuanLy
{
    public partial class ql_giaovien : Form
    {
        connectDB conn = new connectDB();
        public void hienthi()
        {
            String sql = "SELECT * FROM GIAOVIEN";
            SqlCommand cmd = new SqlCommand(sql, conn.Connect());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            ds.DataSource = dt;
        }
        public void loadcombobox()
        {
            conn.Open();
            string sql = "select makhoa,tenkhoa from KHOA";
            SqlCommand cmd = new SqlCommand(sql, conn.Connect());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet set = new DataSet();
            da.Fill(set, "Chọn khoa");
            com_khoa.DataSource = set.Tables[0];
            com_khoa.DisplayMember = "makhoa";
            com_khoa.ValueMember = "makhoa";
            conn.Close();
            
        }

        public void show_com(String txt)
        {
            string sql1 = "select tenkhoa from KHOA where makhoa='"+txt.ToString()+"'";
            SqlCommand cmd1 = new SqlCommand(sql1, conn.Connect());
            SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
            DataTable dt1 = new DataTable();
            da1.Fill(dt1);
            String khoa = "";
            foreach(DataRow r in dt1.Rows)
            {
                khoa = r["tenkhoa"].ToString();
            }
            txt_tenkhoa.Text = khoa.ToString();

        }
        public ql_giaovien()
        {
            InitializeComponent();
        }

        private void ql_giaovien_Load(object sender, EventArgs e)
        {
            hienthi();
            this.loadcombobox();
            String text = com_khoa.Text;
            this.show_com(text);
            
        }

        private void btn_them_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_magv.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập mã giáo viên !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_magv.Focus();
                }
                else if (txt_tengv.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập tên giáo viên !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_tengv.Focus();
                }
                else if (com_chucvu.Text == "")
                {
                    MessageBox.Show("Bạn chưa chọn chức vụ giáo viên !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    com_chucvu.Focus();
                }
                else if (txt_ghichu.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập ghi chú !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_ghichu.Focus();
                }
                else
                {
                    // xuat dl
                    conn.Open();
                    string show="select magiaovien from GIAOVIEN where magiaovien='"+txt_magv.Text+"'";
                    SqlCommand c = new SqlCommand(show, conn.Connect());
                    SqlDataAdapter d = new SqlDataAdapter(c);
                    DataTable dt1 = new DataTable();
                    d.Fill(dt1);
                    conn.Close();
                    String magv = "";
                    foreach (DataRow r in dt1.Rows)
                    {
                        magv = r["magiaovien"].ToString();
                    }

                    if (txt_magv.Text == magv)
                    {
                        MessageBox.Show("Mã giáo viên đã tồn tại. Mời bạn nhập lại !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        txt_magv.Clear();
                        txt_magv.Focus();
                    }
                    else
                    {
                        conn.Open();
                        string sql = "insert into GIAOVIEN (magiaovien,tengiaovien,makhoa,chucvu,ghichu)"
                            + "values('" + txt_magv.Text + "',N'" + txt_tengv.Text + "','" + com_khoa.Text + "',N'" + com_chucvu.Text + "',N'" + txt_ghichu.Text + "')";
                        conn.Excute(sql);
                        MessageBox.Show("Thêm giáo viên thành công !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        hienthi();
                        txt_magv.Clear(); txt_tengv.Clear(); txt_ghichu.Clear();
                        com_khoa.Text = "";
                        com_chucvu.Text = "";
                        txt_magv.Focus();

                    }

                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_sua_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_magv.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập mã giáo viên !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_magv.Focus();
                }
                else if (txt_tengv.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập tên giáo viên !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_tengv.Focus();
                }
                else if (com_chucvu.Text == "")
                {
                    MessageBox.Show("Bạn chưa chọn chức vụ giáo viên !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    com_chucvu.Focus();
                }
                else if (txt_ghichu.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập ghi chú !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_ghichu.Focus();
                }
                else
                {
                    // xuat dl
                    conn.Open();
                    string show = "select magiaovien from GIAOVIEN where magiaovien='" + txt_magv.Text + "'";
                    SqlCommand c = new SqlCommand(show, conn.Connect());
                    SqlDataAdapter d = new SqlDataAdapter(c);
                    DataTable dt1 = new DataTable();
                    d.Fill(dt1);
                    conn.Close();
                    String magv = "";
                    foreach (DataRow r in dt1.Rows)
                    {
                        magv = r["magiaovien"].ToString();
                    }

                    if (txt_magv.Text != magv)
                    {
                        MessageBox.Show("Mã giáo viên không có mời nhập lại !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        txt_magv.Clear();
                        txt_magv.Focus();
                    }
                    else
                    {
                        conn.Open();
                        string sql = "update GIAOVIEN set magiaovien='"+txt_magv.Text+"',tengiaovien=N'"+txt_tengv.Text+"',makhoa='"+com_khoa.Text+"',chucvu=N'"+com_chucvu.Text+"',ghichu=N'"+txt_ghichu.Text+"' where magiaovien='"+txt_magv.Text+"'";
                        conn.Excute(sql);
                        MessageBox.Show("Sửa giáo viên thành công !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        hienthi();
                        txt_magv.Clear(); txt_tengv.Clear(); txt_ghichu.Clear();
                        com_khoa.Text = "";
                        com_chucvu.Text = "";
                        txt_magv.Focus();

                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ds_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int number;
                number = e.RowIndex;
                txt_magv.Text = ds.Rows[number].Cells[0].Value.ToString();
                txt_tengv.Text = ds.Rows[number].Cells[1].Value.ToString();
                com_khoa.Text = ds.Rows[number].Cells[2].Value.ToString();
                com_chucvu.Text = ds.Rows[number].Cells[3].Value.ToString();
                txt_ghichu.Text = ds.Rows[number].Cells[4].Value.ToString();
            }
            catch
            {
                MessageBox.Show("Mời bạn click vào danh sách để show form !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void com_khoa_SelectedIndexChanged(object sender, EventArgs e)
        {

            String text = com_khoa.Text;
            this.show_com(text);
        }

        private void btn_xoa_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_magv.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập mã giáo viên !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_magv.Focus();
                }
                else if (txt_tengv.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập tên giáo viên !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_tengv.Focus();
                }
                else if (com_chucvu.Text == "")
                {
                    MessageBox.Show("Bạn chưa chọn chức vụ giáo viên !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    com_chucvu.Focus();
                }
                else
                {
                    // xuat dl
                    conn.Open();
                    string show = "select magiaovien from GIAOVIEN where magiaovien='" + txt_magv.Text + "'";
                    SqlCommand c = new SqlCommand(show, conn.Connect());
                    SqlDataAdapter d = new SqlDataAdapter(c);
                    DataTable dt1 = new DataTable();
                    d.Fill(dt1);
                    conn.Close();
                    String magv = "";
                    foreach (DataRow r in dt1.Rows)
                    {
                        magv = r["magiaovien"].ToString();
                    }

                    if (txt_magv.Text != magv)
                    {
                        MessageBox.Show("Mã giáo viên không có mời nhập lại !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        txt_magv.Clear();
                        txt_magv.Focus();
                    }
                    else
                    {
                        DialogResult f = MessageBox.Show("Bạn muốn xóa giáo viên không ?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (f == DialogResult.Yes)
                        {
                            conn.Open();
                            string sql = "delete from GIAOVIEN where magiaovien='" + txt_magv.Text + "'";
                            conn.Excute(sql);
                            MessageBox.Show("Xóa giáo viên thành công !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            hienthi();
                            txt_magv.Clear(); txt_tengv.Clear(); txt_ghichu.Clear();
                            com_khoa.Text = "";
                            com_chucvu.Text = "";
                            txt_magv.Focus();
                        }

                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
