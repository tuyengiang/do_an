﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySinhVien.QuanLy
{
    public partial class ql_khoahoc : Form
    {
        connectDB conn = new connectDB();
        public void hienthi()
        {
            String sql = "SELECT * FROM KHOAHOC";
            SqlCommand cmd = new SqlCommand(sql, conn.Connect());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            ds.DataSource = dt;
        }
        public void loadcombobox()
        {
            conn.Open();
            string sql = "select mahe from HE";
            SqlCommand cmd = new SqlCommand(sql, conn.Connect());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet set = new DataSet();
            da.Fill(set, "Chọn hệ");
            com_he.DataSource = set.Tables[0];
            com_he.DisplayMember = "mahe";
            com_he.ValueMember = "mahe";
            conn.Close();

        }
        public void show_com(String txt)
        {
            string sql1 = "select tenhe from HE where mahe='" + txt.ToString() + "'";
            SqlCommand cmd1 = new SqlCommand(sql1, conn.Connect());
            SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
            DataTable dt1 = new DataTable();
            da1.Fill(dt1);
            String khoa = "";
            foreach (DataRow r in dt1.Rows)
            {
                khoa = r["tenhe"].ToString();
            }
            txt_tenhe.Text = khoa.ToString();

        }
        public ql_khoahoc()
        {
            InitializeComponent();
        }

        private void ql_khoahoc_Load(object sender, EventArgs e)
        {
            hienthi();
            this.loadcombobox();
            String text = com_he.Text;
            this.show_com(text);

        }

        private void com_he_SelectedIndexChanged(object sender, EventArgs e)
        {
            String text =com_he.Text;
            this.show_com(text);
        }

        private void btn_them_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_makhoa.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập mã khóa học !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_makhoa.Focus();
                }
                else if (t_tenkhoa.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhậptên khóa học !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    t_tenkhoa.Focus();
                }
                else if (txt_ghichu.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập ghi chú !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_ghichu.Focus();
                }
                else
                {
                    // xuat dl
                    conn.Open();
                    string show = "select makhoahoc from KHOAHOC where makhoahoc='" + txt_makhoa.Text + "'";
                    SqlCommand c = new SqlCommand(show, conn.Connect());
                    SqlDataAdapter d = new SqlDataAdapter(c);
                    DataTable dt1 = new DataTable();
                    d.Fill(dt1);
                    conn.Close();
                    String makhoa = "";
                    foreach (DataRow r in dt1.Rows)
                    {
                        makhoa = r["makhoahoc"].ToString();
                    }
                    if (txt_makhoa.Text == makhoa)
                    {
                        MessageBox.Show("Mã khóa học đã tồn tại. Mời bạn nhập lại !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        txt_makhoa.Clear();
                        txt_makhoa.Focus();
                    }
                    else
                    {
                        conn.Open();
                        string sql = "insert into KHOAHOC (makhoahoc,tenkhoahoc,ngaybatdau,ngayketthuc,mahe,ghichu)"
                            + "values('" + txt_makhoa.Text + "',N'" + t_tenkhoa.Text + "','" + date_begin.Text + "','" + date_end.Text + "','" + com_he.Text + "',N'"+txt_ghichu.Text+"')";
                        conn.Excute(sql);
                        MessageBox.Show("Thêm khóa học thành công !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        hienthi();
                        txt_makhoa.Clear();t_tenkhoa.Clear();
                        com_he.Text = "";
                        txt_ghichu.Clear();
                    }

                }


            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Thông báo",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private void btn_sua_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_makhoa.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập mã khóa học !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_makhoa.Focus();
                }
                else if (t_tenkhoa.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhậptên khóa học !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    t_tenkhoa.Focus();
                }
                else if (txt_ghichu.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập ghi chú !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_ghichu.Focus();
                }
                else
                {
                    // xuat dl
                    conn.Open();
                    string show = "select makhoahoc from KHOAHOC where makhoahoc='" + txt_makhoa.Text + "'";
                    SqlCommand c = new SqlCommand(show, conn.Connect());
                    SqlDataAdapter d = new SqlDataAdapter(c);
                    DataTable dt1 = new DataTable();
                    d.Fill(dt1);
                    conn.Close();
                    String makhoa = "";
                    foreach (DataRow r in dt1.Rows)
                    {
                        makhoa = r["makhoahoc"].ToString();
                    }
                    if (txt_makhoa.Text != makhoa)
                    {
                        MessageBox.Show("Mã khóa học không có !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        txt_makhoa.Clear();
                        txt_makhoa.Focus();
                    }
                    else
                    {
                        conn.Open();
                        string sql = "update KHOAHOC set makhoahoc='" + txt_makhoa.Text + "',tenkhoahoc=N'" + t_tenkhoa.Text + "',ngaybatdau='" + date_begin.Text + "',ngayketthuc='" + date_end.Text + "',mahe='" + com_he.Text + "',ghichu=N'" + txt_ghichu.Text + "' where makhoahoc='"+txt_makhoa.Text+"'";
                        conn.Excute(sql);
                        MessageBox.Show("Sửa khóa học thành công !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        hienthi();
                        txt_makhoa.Clear(); t_tenkhoa.Clear();
                        com_he.Text = "";
                        txt_ghichu.Clear();
                    }

                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ds_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int number;
                number = e.RowIndex;
                txt_makhoa.Text = ds.Rows[number].Cells[0].Value.ToString();
                t_tenkhoa.Text = ds.Rows[number].Cells[1].Value.ToString();
                date_begin.Text = ds.Rows[number].Cells[2].Value.ToString();
                date_end.Text = ds.Rows[number].Cells[3].Value.ToString();
                com_he.Text = ds.Rows[number].Cells[4].Value.ToString();
                txt_ghichu.Text = ds.Rows[number].Cells[5].Value.ToString();
            }
            catch
            {
                MessageBox.Show("Mời bạn click vào danh sách để show form !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void btn_xoa_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_makhoa.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập mã khóa học !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_makhoa.Focus();
                }
                else if (t_tenkhoa.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhậptên khóa học !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    t_tenkhoa.Focus();
                }
                else
                {
                    // xuat dl
                    conn.Open();
                    string show = "select makhoahoc from KHOAHOC where makhoahoc='" + txt_makhoa.Text + "'";
                    SqlCommand c = new SqlCommand(show, conn.Connect());
                    SqlDataAdapter d = new SqlDataAdapter(c);
                    DataTable dt1 = new DataTable();
                    d.Fill(dt1);
                    conn.Close();
                    String makhoa = "";
                    foreach (DataRow r in dt1.Rows)
                    {
                        makhoa = r["makhoahoc"].ToString();
                    }
                    if (txt_makhoa.Text != makhoa)
                    {
                        MessageBox.Show("Mã khóa học không có !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        txt_makhoa.Clear();
                        txt_makhoa.Focus();
                    }
                    else
                    {
                        DialogResult f = MessageBox.Show("Bạn muốn xóa khoá học không ?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (f == DialogResult.Yes)
                        {
                            conn.Open();
                            string sql = "delete from KHOAHOC  where makhoahoc='" + txt_makhoa.Text + "'";
                            conn.Excute(sql);
                            MessageBox.Show("Xóa khóa học thành công !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            hienthi();
                            txt_makhoa.Clear(); t_tenkhoa.Clear();
                            com_he.Text = "";
                            txt_ghichu.Clear();
                        }
                    }

                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
