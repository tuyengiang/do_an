﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySinhVien.QuanLy
{
    public partial class ql_khoa : Form
    {
        connectDB conn = new connectDB();
        public void hienthi()
        {
            String sql = "SELECT * FROM KHOA";
            SqlCommand cmd = new SqlCommand(sql, conn.Connect());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            ds.DataSource = dt;
        }
        public ql_khoa()
        {
            InitializeComponent();
        }

        private void ql_khoa_Load(object sender, EventArgs e)
        {
            hienthi();
        }

        private void btn_them_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_makhoa.Text == "")
                {
                    MessageBox.Show("Mời bạn nhập mã khoa !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_makhoa.Focus();
                }
                else if(txt_tenkhoa.Text == "")
                {
                    MessageBox.Show("Mời bạn nhập tên khoa !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_tenkhoa.Focus();
                }
                else if (txt_sogiangvien.Text == "")
                {
                    MessageBox.Show("Mời bạn nhập số giảng viên giảng dạy !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_sogiangvien.Focus();
                }
                else if (txt_ghichu.Text == "")
                {
                    MessageBox.Show("Mời bạn nhập ghi chú !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_ghichu.Focus();
                }
                else
                {
                    conn.Open();
                    String out_put="select makhoa from KHOA where makhoa='"+txt_makhoa.Text+"'";
                    SqlCommand cmd1 = new SqlCommand(out_put, conn.Connect());
                    SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
                    DataTable dt1 = new DataTable();
                    da1.Fill(dt1);
                    conn.Close();

                    String makhoa = "";
                    foreach(DataRow d in dt1.Rows)
                    {
                        makhoa = d["makhoa"].ToString();
                    }

                    if (txt_makhoa.Text == makhoa)
                    {
                        MessageBox.Show("Mã khoa bạn nhập đã tồn tại. Mời nhập lại!!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        txt_makhoa.Clear();
                        txt_makhoa.Focus();
                    }
                    else
                    {
                        conn.Open();
                        string sql = "insert into KHOA(makhoa,tenkhoa,socanbogiangday,ghichu)" +
                            "values('"+txt_makhoa.Text+"',N'"+txt_tenkhoa.Text+"','"+txt_sogiangvien.Text+"','"+txt_ghichu.Text+"')";
                        conn.Excute(sql);
                        MessageBox.Show("Thêm khoa thành công !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        hienthi();
                        txt_makhoa.Clear();txt_tenkhoa.Clear(); txt_sogiangvien.Clear(); txt_ghichu.Clear();
                        txt_makhoa.Focus();
                    }
                }
                

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ds_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int number;
                number = e.RowIndex;
                txt_makhoa.Text = ds.Rows[number].Cells[0].Value.ToString();
                txt_tenkhoa.Text = ds.Rows[number].Cells[1].Value.ToString();
                txt_sogiangvien.Text = ds.Rows[number].Cells[2].Value.ToString();
                txt_ghichu.Text = ds.Rows[number].Cells[3].Value.ToString();
            }
            catch
            {
                MessageBox.Show("Mời bạn click vào danh sách để show form !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void btn_sua_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_makhoa.Text == "")
                {
                    MessageBox.Show("Mời bạn nhập mã khoa !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_makhoa.Focus();
                }
                else if (txt_tenkhoa.Text == "")
                {
                    MessageBox.Show("Mời bạn nhập tên khoa !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_tenkhoa.Focus();
                }
                else if (txt_sogiangvien.Text == "")
                {
                    MessageBox.Show("Mời bạn nhập số giảng viên giảng dạy !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_sogiangvien.Focus();
                }
                else if (txt_ghichu.Text == "")
                {
                    MessageBox.Show("Mời bạn nhập ghi chú !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_ghichu.Focus();
                }
                else
                {
                    conn.Open();
                    String out_put = "select makhoa from KHOA where makhoa='" + txt_makhoa.Text + "'";
                    SqlCommand cmd1 = new SqlCommand(out_put, conn.Connect());
                    SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
                    DataTable dt1 = new DataTable();
                    da1.Fill(dt1);
                    conn.Close();

                    String makhoa = "";
                    foreach (DataRow d in dt1.Rows)
                    {
                        makhoa = d["makhoa"].ToString();
                    }

                    if (txt_makhoa.Text != makhoa)
                    {
                        MessageBox.Show("Mã khoa bạn nhập không đúng !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        txt_makhoa.Clear();
                        txt_makhoa.Focus();
                    }
                    else
                    {
                        conn.Open();
                        string sql = "update KHOA set makhoa='" + txt_makhoa.Text + "',tenkhoa=N'" + txt_tenkhoa.Text + "',socanbogiangday='" + txt_sogiangvien.Text + "',ghichu='" + txt_ghichu.Text + "' where makhoa='"+txt_makhoa.Text+"'";
                        conn.Excute(sql);
                        MessageBox.Show("Sửa khoa thành công !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        hienthi();
                        txt_makhoa.Clear(); txt_tenkhoa.Clear(); txt_sogiangvien.Clear(); txt_ghichu.Clear();
                        txt_makhoa.Focus();
                    }
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_xoa_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_makhoa.Text == "")
                {
                    MessageBox.Show("Mời bạn nhập mã khoa !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_makhoa.Focus();
                }
                else if (txt_tenkhoa.Text == "")
                {
                    MessageBox.Show("Mời bạn nhập tên khoa !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_tenkhoa.Focus();
                }
                else if (txt_sogiangvien.Text == "")
                {
                    MessageBox.Show("Mời bạn nhập số giảng viên giảng dạy !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_sogiangvien.Focus();
                }
                else
                {
                    conn.Open();
                    String out_put = "select makhoa from KHOA where makhoa='" + txt_makhoa.Text + "'";
                    SqlCommand cmd1 = new SqlCommand(out_put, conn.Connect());
                    SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
                    DataTable dt1 = new DataTable();
                    da1.Fill(dt1);
                    conn.Close();

                    String makhoa = "";
                    foreach (DataRow d in dt1.Rows)
                    {
                        makhoa = d["makhoa"].ToString();
                    }

                    if (txt_makhoa.Text != makhoa)
                    {
                        MessageBox.Show("Mã bạn nhập không có !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        txt_makhoa.Clear();
                        txt_makhoa.Focus();
                    }
                    else
                    {
                        DialogResult f = MessageBox.Show("Bạn muốn xóa khoa không ?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (f == DialogResult.Yes)
                        {
                            conn.Open();
                            string sql = "delete from KHOA where makhoa='" + txt_makhoa.Text + "'";
                            conn.Excute(sql);
                            MessageBox.Show("Xóa khoa thành công !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            hienthi();
                            txt_makhoa.Clear(); txt_tenkhoa.Clear(); txt_sogiangvien.Clear(); txt_ghichu.Clear();
                            txt_makhoa.Focus();
                        }
                    }
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
