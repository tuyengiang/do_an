﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySinhVien.QuanLy
{
    public partial class ql_monhoc : Form
    {
        connectDB conn = new connectDB();
        public void hienthi()
        {
            String sql = "SELECT * FROM MONHOC";
            SqlCommand cmd = new SqlCommand(sql, conn.Connect());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            ds.DataSource = dt;
        }
        public void loadcombobox()
        {
            conn.Open();
            string sql = "select tengiaovien from GIAOVIEN";
            SqlCommand cmd = new SqlCommand(sql, conn.Connect());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet set = new DataSet();
            da.Fill(set, "Chọn tên giáo viên");
            com_giaovien.DataSource = set.Tables[0];
            com_giaovien.DisplayMember = "tengiaovien";
            com_giaovien.ValueMember = "tengiaovien";
            conn.Close();

        }
        public ql_monhoc()
        {
            InitializeComponent();
        }

        private void ql_monhoc_Load(object sender, EventArgs e)
        {
            hienthi();
            this.loadcombobox();

        }

        private void btn_them_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_mamh.Text == "")
                {
                    MessageBox.Show("Mời bạn nhập mã môn học !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_mamh.Focus();
                }
                else if (txt_tenmh.Text == "")
                {
                    MessageBox.Show("Mời bạn nhập tên môn học !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_tenmh.Focus();
                }
                else if (txt_hocky.Text == "")
                {
                    MessageBox.Show("Mời bạn nhập học kỳ !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_hocky.Focus();
                }
                else if (txt_sotc.Text == "")
                {
                    MessageBox.Show("Mời bạn nhập số tín chỉ !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_sotc.Focus();
                }
                else if (com_giaovien.Text == "")
                {
                    MessageBox.Show("Mời bạn chọn giáo viên dậy học !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    com_giaovien.Focus();
                }
                else if (txt_ghichu.Text == "")
                {
                    MessageBox.Show("Mời bạn nhập số tín chỉ !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_ghichu.Focus();
                }
                else
                {
                    // xuat dl
                    conn.Open();
                    string show = "select mamh from MONHOC where mamh='" + txt_mamh.Text + "'";
                    SqlCommand c = new SqlCommand(show, conn.Connect());
                    SqlDataAdapter d = new SqlDataAdapter(c);
                    DataTable dt1 = new DataTable();
                    d.Fill(dt1);
                    conn.Close();
                    String mamon = "";
                    foreach (DataRow r in dt1.Rows)
                    {
                        mamon = r["mamh"].ToString();
                    }

                    if (txt_mamh.Text == mamon)
                    {
                        MessageBox.Show("Mã môn học đã tồn tại. Mời nhập lại !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        txt_mamh.Clear();
                        txt_mamh.Focus();
                    }
                    else
                    {
                        conn.Open();
                        String sql = "insert into MONHOC(mamh,tenmh,ngaydangky,hocky,stc,ngaybatdau,ngayketthuc,tengiaovien,ghichu) " +
                            "values('" + txt_mamh.Text + "',N'" + txt_tenmh.Text + "','" + date_register.Text + "',N'" + txt_hocky.Text + "','" + txt_sotc.Text + "','" + date_begin.Text + "','" + date_end.Text + "',N'" + com_giaovien.Text + "',N'" + txt_ghichu.Text + "')";
                        conn.Excute(sql);
                        MessageBox.Show("Thêm môn học thành công !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        hienthi();
                        txt_mamh.Clear(); txt_tenmh.Clear(); txt_hocky.Clear(); txt_sotc.Clear(); txt_ghichu.Clear(); com_giaovien.Text = "";
                        txt_mamh.Focus();

                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_sua_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_mamh.Text == "")
                {
                    MessageBox.Show("Mời bạn nhập mã môn học !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_mamh.Focus();
                }
                else if (txt_tenmh.Text == "")
                {
                    MessageBox.Show("Mời bạn nhập tên môn học !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_tenmh.Focus();
                }
                else if (txt_hocky.Text == "")
                {
                    MessageBox.Show("Mời bạn nhập học kỳ !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_hocky.Focus();
                }
                else if (txt_sotc.Text == "")
                {
                    MessageBox.Show("Mời bạn nhập số tín chỉ !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_sotc.Focus();
                }
                else if (com_giaovien.Text == "")
                {
                    MessageBox.Show("Mời bạn chọn giáo viên dậy học !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    com_giaovien.Focus();
                }
                else if (txt_ghichu.Text == "")
                {
                    MessageBox.Show("Mời bạn nhập số tín chỉ !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_ghichu.Focus();
                }
                else
                {
                    // xuat dl
                    conn.Open();
                    string show = "select mamh from MONHOC where mamh='" + txt_mamh.Text + "'";
                    SqlCommand c = new SqlCommand(show, conn.Connect());
                    SqlDataAdapter d = new SqlDataAdapter(c);
                    DataTable dt1 = new DataTable();
                    d.Fill(dt1);
                    conn.Close();
                    String mamon = "";
                    foreach (DataRow r in dt1.Rows)
                    {
                        mamon = r["mamh"].ToString();
                    }

                    if (txt_mamh.Text != mamon)
                    {
                        MessageBox.Show("Mã môn học không tồn tại !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        txt_mamh.Clear();
                        txt_mamh.Focus();
                    }
                    else
                    {
                        conn.Open();
                        String sql = "update MONHOC set mamh='" + txt_mamh.Text + "',tenmh=N'" + txt_tenmh.Text + "',ngaydangky='" + date_register.Text + "',hocky=N'" + txt_hocky.Text + "',stc='" + txt_sotc.Text + "',ngaybatdau='" + date_begin.Text + "',ngayketthuc='" + date_end.Text + "',tengiaovien=N'" + com_giaovien.Text + "',ghichu=N'" + txt_ghichu.Text + "' where mamh='"+txt_mamh.Text+"'";
                        conn.Excute(sql);
                        MessageBox.Show("Sửa môn học thành công !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        hienthi();
                        txt_mamh.Clear(); txt_tenmh.Clear(); txt_hocky.Clear(); txt_sotc.Clear(); txt_ghichu.Clear(); com_giaovien.Text = "";
                        txt_mamh.Focus();

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ds_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int number;
                number = e.RowIndex;
                txt_mamh.Text = ds.Rows[number].Cells[0].Value.ToString();
                txt_tenmh.Text = ds.Rows[number].Cells[1].Value.ToString();
                date_register.Text = ds.Rows[number].Cells[2].Value.ToString();
                txt_hocky.Text = ds.Rows[number].Cells[3].Value.ToString();
                txt_sotc.Text = ds.Rows[number].Cells[4].Value.ToString();
                date_begin.Text = ds.Rows[number].Cells[5].Value.ToString();
                date_end.Text = ds.Rows[number].Cells[6].Value.ToString();
                com_giaovien.Text = ds.Rows[number].Cells[7].Value.ToString();
                txt_ghichu.Text = ds.Rows[number].Cells[8].Value.ToString();
            }
            catch {
                MessageBox.Show("Mời bạn click vào danh sách để show form !!!", "Thông báo", MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
            }
        }

        private void btn_xoa_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_mamh.Text == "")
                {
                    MessageBox.Show("Mời bạn nhập mã môn học !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_mamh.Focus();
                }
                else if (txt_tenmh.Text == "")
                {
                    MessageBox.Show("Mời bạn nhập tên môn học !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_tenmh.Focus();
                }
                else if (txt_hocky.Text == "")
                {
                    MessageBox.Show("Mời bạn nhập học kỳ !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_hocky.Focus();
                }
                else if (txt_sotc.Text == "")
                {
                    MessageBox.Show("Mời bạn nhập số tín chỉ !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_sotc.Focus();
                }
                else if (com_giaovien.Text == "")
                {
                    MessageBox.Show("Mời bạn chọn giáo viên dậy học !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    com_giaovien.Focus();
                }
                else
                {
                    // xuat dl
                    conn.Open();
                    string show = "select mamh from MONHOC where mamh='" + txt_mamh.Text + "'";
                    SqlCommand c = new SqlCommand(show, conn.Connect());
                    SqlDataAdapter d = new SqlDataAdapter(c);
                    DataTable dt1 = new DataTable();
                    d.Fill(dt1);
                    conn.Close();
                    String mamon = "";
                    foreach (DataRow r in dt1.Rows)
                    {
                        mamon = r["mamh"].ToString();
                    }

                    if (txt_mamh.Text != mamon)
                    {
                        MessageBox.Show("Mã môn học không tồn tại !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        txt_mamh.Clear();
                        txt_mamh.Focus();
                    }
                    else
                    {
                        DialogResult f = MessageBox.Show("Bạn muốn xóa môn học không ?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (f == DialogResult.Yes)
                        {
                            conn.Open();
                            String sql = "delete from MONHOC where mamh='" + txt_mamh.Text + "'";
                            conn.Excute(sql);
                            MessageBox.Show("Xóa môn học thành công !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            hienthi();
                            txt_mamh.Clear(); txt_tenmh.Clear(); txt_hocky.Clear(); txt_sotc.Clear(); txt_ghichu.Clear(); com_giaovien.Text = "";
                            txt_mamh.Focus();
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ds_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
