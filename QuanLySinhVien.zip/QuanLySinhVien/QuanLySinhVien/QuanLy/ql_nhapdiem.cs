﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySinhVien.QuanLy
{
    public partial class ql_nhapdiem : Form
    {
        connectDB conn = new connectDB();
        public ql_nhapdiem()
        {
            InitializeComponent();
        }
        public void hienthi()
        {
            String sql = "SELECT * FROM DIEM";
            SqlCommand cmd = new SqlCommand(sql, conn.Connect());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            ds.DataSource = dt;
        }
        public void loadcombobox_sinhvien()
        {
            conn.Open();
            string sql = "select masv from SINHVIEN";
            SqlCommand cmd = new SqlCommand(sql, conn.Connect());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet set = new DataSet();
            da.Fill(set, "Chọn mã sinh viên");
            com_sv.DataSource = set.Tables[0];
            com_sv.DisplayMember = "masv";
            com_sv.ValueMember = "masv";
            conn.Close();

        }
        public void loadcombobox_monhoc()
        {
            conn.Open();
            string sql = "select mamh from MONHOC";
            SqlCommand cmd = new SqlCommand(sql, conn.Connect());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet set = new DataSet();
            da.Fill(set, "Chọn mã môn học");
            com_mon.DataSource = set.Tables[0];
            com_mon.DisplayMember = "mamh";
            com_mon.ValueMember = "mamh";
            conn.Close();

        }


        public void show_com_mh(String txt)
        {
            string sql1 = "select tenmh from MONHOC where mamh='" + txt.ToString() + "'";
            SqlCommand cmd1 = new SqlCommand(sql1, conn.Connect());
            SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
            DataTable dt1 = new DataTable();
            da1.Fill(dt1);
            String khoa = "";
            foreach (DataRow r in dt1.Rows)
            {
                khoa = r["tenmh"].ToString();
            }
            txt_tenmon.Text = khoa.ToString();

        }
        public void show_com_sv(String txt)
        {
            string sql1 = "select tensv from SINHVIEN where masv='" + txt.ToString() + "'";
            SqlCommand cmd1 = new SqlCommand(sql1, conn.Connect());
            SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
            DataTable dt1 = new DataTable();
            da1.Fill(dt1);
            String khoa = "";
            foreach (DataRow r in dt1.Rows)
            {
                khoa = r["tensv"].ToString();
            }
            txt_tensv.Text = khoa.ToString();

        }
        private void ql_nhapdiem_Load(object sender, EventArgs e)
        {
            hienthi();
            this.loadcombobox_sinhvien();
            this.loadcombobox_monhoc();
            String text1 = com_mon.Text;
            this.show_com_mh(text1);
            String text = com_sv.Text;
            this.show_com_sv(text);
        }

        private void com_sv_SelectedIndexChanged(object sender, EventArgs e)
        {
            String text = com_sv.Text;
            this.show_com_sv(text);
        }

        private void com_mon_SelectedIndexChanged(object sender, EventArgs e)
        {
            String text1 = com_mon.Text;
            this.show_com_mh(text1);
        }

        private void btn_them_Click(object sender, EventArgs e)
        {
            try
            {
                if (com_sv.Text == "")
                {
                    MessageBox.Show("Bạn chưa chọn mã sinh viên !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    com_sv.Focus();
                }
                else if (com_mon.Text == "")
                {
                    MessageBox.Show("Bạn chưa chọn mã môn học !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    com_mon.Focus();
                }
                else if (txt_diem1.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập điểm thi !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_diem1.Focus();
                }
                else if (txt_lanthi.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập số lần thi !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_lanthi.Focus();
                }
                else if (txt_ghichu.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập ghi chú !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_ghichu.Focus();
                }
                else
                {
                    conn.Open();
                    string show = "select mamh from DIEM where masv='" + com_sv.Text + "'";
                    SqlCommand c = new SqlCommand(show, conn.Connect());
                    SqlDataAdapter d = new SqlDataAdapter(c);
                    DataTable dt1 = new DataTable();
                    d.Fill(dt1);
                    conn.Close();
                    String mamon = "";
                    foreach (DataRow r in dt1.Rows)
                    {
                        mamon = r["mamh"].ToString();
                    }

                    if (com_mon.Text == mamon)
                    {
                        MessageBox.Show("Môn học của sinh viên đã được nhập điểm. Mời nhập lại !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        com_mon.Text = "";
                        com_mon.Focus();
                    }
                    else
                    {
                        if (txt_diem2.Text == "")
                        {
                            conn.Open();
                            String sql = "insert into DIEM (masv,mamh,diemlan1,diemlan2,lanthi,ngaythi,ghichu)" +
                                "values('" + com_sv.Text + "','" + com_mon.Text + "','" + txt_diem1.Text + "',NULL,'" + txt_lanthi.Text + "','" + date_ngaythi.Text + "',N'" + txt_ghichu.Text + "')";
                            conn.Excute(sql);
                            MessageBox.Show("Thêm điểm sinh viên thành công !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            hienthi();
                            com_sv.Text = ""; com_mon.Text = "";
                            txt_diem1.Clear(); txt_diem2.Clear(); txt_lanthi.Clear(); txt_ghichu.Text = "";
                            com_sv.Focus();
                        }
                        else
                        {
                            conn.Open();
                            String sql = "insert into DIEM (masv,mamh,diemlan1,diemlan2,lanthi,ngaythi,ghichu)" +
                                "values('" + com_sv.Text + "','" + com_mon.Text + "','" + txt_diem1.Text + "','" + txt_diem2.Text + "','" + txt_lanthi.Text + "','" + date_ngaythi.Text + "',N'" + txt_ghichu.Text + "')";
                            conn.Excute(sql);
                            MessageBox.Show("Thêm điểm sinh viên thành công !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            hienthi();
                            com_sv.Text = ""; com_mon.Text = "";
                            txt_diem1.Clear(); txt_diem2.Clear(); txt_lanthi.Clear(); txt_ghichu.Text = "";
                            com_sv.Focus();
                        }
                    }
                }
            }catch(Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_sua_Click(object sender, EventArgs e)
        {
            try
            {
                if (com_sv.Text == "")
                {
                    MessageBox.Show("Bạn chưa chọn mã sinh viên !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    com_sv.Focus();
                }
                else if (com_mon.Text == "")
                {
                    MessageBox.Show("Bạn chưa chọn mã môn học !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    com_mon.Focus();
                }
                else if (txt_diem1.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập điểm thi !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_diem1.Focus();
                }
                else if (txt_lanthi.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập số lần thi !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_lanthi.Focus();
                }
                else if (txt_ghichu.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập ghi chú !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_ghichu.Focus();
                }
                else
                {
                        conn.Open();
                        String sql = "update DIEM set masv='" + com_sv.Text + "',mamh='" + com_mon.Text + "',diemlan1='" + txt_diem1.Text + "',diemlan2='" + txt_diem2.Text + "',lanthi='" + txt_lanthi.Text + "',ngaythi='" + date_ngaythi.Text + "',ghichu=N'" + txt_ghichu.Text + "' where masv='" + com_sv.Text + "' and mamh='"+com_mon.Text+"'";
                        conn.Excute(sql);
                        MessageBox.Show("Sửa điểm sinh viên thành công !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        hienthi();
                        com_sv.Text = ""; com_mon.Text = "";
                        txt_diem1.Clear(); txt_diem2.Clear(); txt_lanthi.Clear(); txt_ghichu.Text = "";
                        com_sv.Focus();
                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ds_Click(object sender, EventArgs e)
        {

        }

        private void ds_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int number;
            number = e.RowIndex;
            com_sv.Text = ds.Rows[number].Cells[0].Value.ToString();
            com_mon.Text = ds.Rows[number].Cells[1].Value.ToString();
            txt_diem1.Text = ds.Rows[number].Cells[2].Value.ToString();
            txt_diem2.Text = ds.Rows[number].Cells[3].Value.ToString();
            txt_lanthi.Text = ds.Rows[number].Cells[4].Value.ToString();
            date_ngaythi.Text = ds.Rows[number].Cells[5].Value.ToString();
            txt_ghichu.Text = ds.Rows[number].Cells[6].Value.ToString();
        }

        private void btn_xoa_Click(object sender, EventArgs e)
        {
            try
            {
                if (com_sv.Text == "")
                {
                    MessageBox.Show("Bạn chưa chọn mã sinh viên !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    com_sv.Focus();
                }
                else if (com_mon.Text == "")
                {
                    MessageBox.Show("Bạn chưa chọn mã môn học !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    com_mon.Focus();
                }
                else if (txt_diem1.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập điểm thi !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_diem1.Focus();
                }
                else if (txt_lanthi.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập số lần thi !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_lanthi.Focus();
                }
                
                else
                {
                   
                        conn.Open();
                        String sql = "delete from DIEM  where masv='" + com_sv.Text + "' and mamh='" + com_mon.Text + "'";
                        conn.Excute(sql);
                        DialogResult f = MessageBox.Show("Bạn muốn xóa điểm sinh viên k ?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (f == DialogResult.Yes)
                        {
                            MessageBox.Show("Xóa điểm sinh viên thành công !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            hienthi();
                            com_sv.Text = ""; com_mon.Text = "";
                            txt_diem1.Clear(); txt_diem2.Clear(); txt_lanthi.Clear(); txt_ghichu.Text = "";
                            com_sv.Focus();
                        }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
    }
}
