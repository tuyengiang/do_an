﻿namespace QuanLySinhVien.TimKiem
{
    partial class tk_sinhvien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(tk_sinhvien));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_load = new DevExpress.XtraEditors.SimpleButton();
            this.com_list = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_key = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_timkiem = new DevExpress.XtraEditors.SimpleButton();
            this.label1 = new System.Windows.Forms.Label();
            this.ds = new System.Windows.Forms.DataGridView();
            this.masv = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tensv = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gioitinh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.diach = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.malo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.khoa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sdt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ghichu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_export = new DevExpress.XtraEditors.SimpleButton();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ds)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn_export);
            this.groupBox1.Controls.Add(this.btn_load);
            this.groupBox1.Controls.Add(this.com_list);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txt_key);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.btn_timkiem);
            this.groupBox1.Location = new System.Drawing.Point(63, 84);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(981, 86);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tìm kiếm sinh viên";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // btn_load
            // 
            this.btn_load.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.btn_load.Appearance.Options.UseFont = true;
            this.btn_load.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_load.ImageOptions.Image")));
            this.btn_load.Location = new System.Drawing.Point(642, 29);
            this.btn_load.Name = "btn_load";
            this.btn_load.Size = new System.Drawing.Size(101, 34);
            this.btn_load.TabIndex = 2;
            this.btn_load.Text = "Load DL";
            this.btn_load.Click += new System.EventHandler(this.btn_load_Click);
            // 
            // com_list
            // 
            this.com_list.FormattingEnabled = true;
            this.com_list.Items.AddRange(new object[] {
            "Mã sinh viên",
            "Tên sinh viên",
            "Địa chỉ",
            "Mã lớp",
            "Mã khoa"});
            this.com_list.Location = new System.Drawing.Point(460, 32);
            this.com_list.Name = "com_list";
            this.com_list.Size = new System.Drawing.Size(162, 28);
            this.com_list.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(336, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(107, 20);
            this.label3.TabIndex = 12;
            this.label3.Text = "Tìm kiếm theo";
            // 
            // txt_key
            // 
            this.txt_key.Location = new System.Drawing.Point(153, 34);
            this.txt_key.Name = "txt_key";
            this.txt_key.Size = new System.Drawing.Size(158, 26);
            this.txt_key.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(128, 20);
            this.label2.TabIndex = 11;
            this.label2.Text = "Từ khóa tìm kiếm";
            // 
            // btn_timkiem
            // 
            this.btn_timkiem.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.btn_timkiem.Appearance.Options.UseFont = true;
            this.btn_timkiem.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_timkiem.ImageOptions.Image")));
            this.btn_timkiem.Location = new System.Drawing.Point(862, 29);
            this.btn_timkiem.Name = "btn_timkiem";
            this.btn_timkiem.Size = new System.Drawing.Size(101, 34);
            this.btn_timkiem.TabIndex = 4;
            this.btn_timkiem.Text = "Tìm kiếm";
            this.btn_timkiem.Click += new System.EventHandler(this.btn_timkiem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(242, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(466, 39);
            this.label1.TabIndex = 5;
            this.label1.Text = "Tìm kiếm thông tin sinh viên";
            // 
            // ds
            // 
            this.ds.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.ds.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.ds.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ds.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.masv,
            this.tensv,
            this.date,
            this.gioitinh,
            this.diach,
            this.malo,
            this.khoa,
            this.sdt,
            this.ghichu});
            this.ds.Location = new System.Drawing.Point(63, 176);
            this.ds.Name = "ds";
            this.ds.Size = new System.Drawing.Size(981, 328);
            this.ds.TabIndex = 7;
            // 
            // masv
            // 
            this.masv.DataPropertyName = "masv";
            this.masv.HeaderText = "Mã sinh viên";
            this.masv.Name = "masv";
            // 
            // tensv
            // 
            this.tensv.DataPropertyName = "tensv";
            this.tensv.HeaderText = "Tên sinh viên";
            this.tensv.Name = "tensv";
            // 
            // date
            // 
            this.date.DataPropertyName = "ngaysinh";
            this.date.HeaderText = "Ngày sinh";
            this.date.Name = "date";
            // 
            // gioitinh
            // 
            this.gioitinh.DataPropertyName = "gioitinh";
            this.gioitinh.HeaderText = "Giới Tính";
            this.gioitinh.Name = "gioitinh";
            // 
            // diach
            // 
            this.diach.DataPropertyName = "diachi";
            this.diach.HeaderText = "Địa chỉ";
            this.diach.Name = "diach";
            // 
            // malo
            // 
            this.malo.DataPropertyName = "malop";
            this.malo.HeaderText = "Mã lớp";
            this.malo.Name = "malo";
            // 
            // khoa
            // 
            this.khoa.DataPropertyName = "makhoa";
            this.khoa.HeaderText = "Mã khoa";
            this.khoa.Name = "khoa";
            // 
            // sdt
            // 
            this.sdt.DataPropertyName = "sdt";
            this.sdt.HeaderText = "Số điện thoại";
            this.sdt.Name = "sdt";
            // 
            // ghichu
            // 
            this.ghichu.DataPropertyName = "ghichu";
            this.ghichu.HeaderText = "Ghi chú";
            this.ghichu.Name = "ghichu";
            // 
            // btn_export
            // 
            this.btn_export.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.btn_export.Appearance.Options.UseFont = true;
            this.btn_export.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_export.ImageOptions.Image")));
            this.btn_export.Location = new System.Drawing.Point(752, 29);
            this.btn_export.Name = "btn_export";
            this.btn_export.Size = new System.Drawing.Size(101, 34);
            this.btn_export.TabIndex = 3;
            this.btn_export.Text = "Export";
            this.btn_export.Click += new System.EventHandler(this.btn_export_Click);
            // 
            // tk_sinhvien
            // 
            this.AcceptButton = this.btn_timkiem;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 692);
            this.Controls.Add(this.ds);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "tk_sinhvien";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tìm kiếm thông tin sinh viên";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.tk_sinhvien_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ds)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private DevExpress.XtraEditors.SimpleButton btn_load;
        private System.Windows.Forms.ComboBox com_list;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_key;
        private System.Windows.Forms.Label label2;
        private DevExpress.XtraEditors.SimpleButton btn_timkiem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView ds;
        private System.Windows.Forms.DataGridViewTextBoxColumn masv;
        private System.Windows.Forms.DataGridViewTextBoxColumn tensv;
        private System.Windows.Forms.DataGridViewTextBoxColumn date;
        private System.Windows.Forms.DataGridViewTextBoxColumn gioitinh;
        private System.Windows.Forms.DataGridViewTextBoxColumn diach;
        private System.Windows.Forms.DataGridViewTextBoxColumn malo;
        private System.Windows.Forms.DataGridViewTextBoxColumn khoa;
        private System.Windows.Forms.DataGridViewTextBoxColumn sdt;
        private System.Windows.Forms.DataGridViewTextBoxColumn ghichu;
        private DevExpress.XtraEditors.SimpleButton btn_export;
    }
}