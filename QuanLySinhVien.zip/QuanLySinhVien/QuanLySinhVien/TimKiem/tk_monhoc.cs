﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySinhVien.TimKiem
{
    public partial class tk_monhoc : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=QLSV;Integrated Security=True");

        public void hienthi()
        {
            String sql = "SELECT * FROM MONHOC";
            SqlCommand cmd = new SqlCommand(sql, conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            ds.DataSource = dt;
        }
        public tk_monhoc()
        {
            InitializeComponent();
        }

        private void com_list_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void tk_monhoc_Load(object sender, EventArgs e)
        {
            hienthi();
     
        }

        private void btn_load_Click(object sender, EventArgs e)
        {
            hienthi();
            txt_key.Clear();
            com_list.Text = "";
        }

        private void btn_timkiem_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_key.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập từ khóa !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txt_key.Focus();
                }
                else if (com_list.Text == "")
                {
                    MessageBox.Show("Bạn chưa chọn tìm kiếm theo !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    com_list.Focus();
                }
                else
                {
                    Boolean kt = false;
                    int count;
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("SELECT count(*) FROM MONHOC where mamh like N'%" + txt_key.Text + "%' ", conn);
                    count = (int)cmd.ExecuteScalar();
                    conn.Close();
                    if (count != 0 && com_list.Text == "Mã môn học")
                    {
                        kt = true;
                    }
                    if (kt == true)
                    {
                        MessageBox.Show("Tìm thấy dữ liệu !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        conn.Open();
                        SqlCommand com = new SqlCommand("SELECT * FROM MONHOC where mamh like N'%" + txt_key.Text + "%' ", conn);
                        SqlDataAdapter da = new SqlDataAdapter(com);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        ds.DataSource = dt;
                        conn.Close();
                    }
                    else
                    {
                        conn.Open();
                        SqlCommand tenmh = new SqlCommand("SELECT count(*) FROM MONHOC where tenmh like N'%" + txt_key.Text + "%' ", conn);
                        count = (int)tenmh.ExecuteScalar();
                        conn.Close();
                        if (count != 0 && com_list.Text == "Tên môn học")
                        {
                            kt = true;
                        }
                        if (kt == true)
                        {
                            MessageBox.Show("Tìm thấy dữ liệu !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            conn.Open();
                            SqlCommand com = new SqlCommand("SELECT * FROM MONHOC where tenmh like N'%" + txt_key.Text + "%' ", conn);
                            SqlDataAdapter da = new SqlDataAdapter(com);
                            DataTable dt = new DataTable();
                            da.Fill(dt);
                            ds.DataSource = dt;
                            conn.Close();
                        }
                        else
                        {
                            conn.Open();
                            SqlCommand tengv = new SqlCommand("SELECT count(*) FROM MONHOC where tengiaovien like N'%" + txt_key.Text + "%' ", conn);
                            count = (int)tengv.ExecuteScalar();
                            conn.Close();
                            if (count != 0 && com_list.Text == "Tên giáo viên")
                            {
                                kt = true;
                            }
                            if (kt == true)
                            {
                                MessageBox.Show("Tìm thấy dữ liệu !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                conn.Open();
                                SqlCommand com = new SqlCommand("SELECT * FROM MONHOC where tengiaovien like N'%" + txt_key.Text + "%' ", conn);
                                SqlDataAdapter da = new SqlDataAdapter(com);
                                DataTable dt = new DataTable();
                                da.Fill(dt);
                                ds.DataSource = dt;
                                conn.Close();
                            }
                            else
                            {
                                conn.Open();
                                SqlCommand stc = new SqlCommand("SELECT count(*) FROM MONHOC where stc like N'%" + txt_key.Text + "%' ", conn);
                                count = (int)stc.ExecuteScalar();
                                conn.Close();
                                if (count != 0 && com_list.Text == "Số tín chỉ")
                                {
                                    kt = true;
                                }
                                if (kt == true)
                                {
                                    MessageBox.Show("Tìm thấy dữ liệu !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                    conn.Open();
                                    SqlCommand com = new SqlCommand("SELECT * FROM MONHOC where stc like N'%" + txt_key.Text + "%' ", conn);
                                    SqlDataAdapter da = new SqlDataAdapter(com);
                                    DataTable dt = new DataTable();
                                    da.Fill(dt);
                                    ds.DataSource = dt;
                                    conn.Close();
                                }
                                else
                                {
                                    conn.Open();
                                    SqlCommand hk = new SqlCommand("SELECT count(*) FROM MONHOC where hocky like N'%" + txt_key.Text + "%' ", conn);
                                    count = (int)hk.ExecuteScalar();
                                    conn.Close();
                                    if (count != 0 && com_list.Text == "Học kỳ")
                                    {
                                        kt = true;
                                    }
                                    if (kt == true)
                                    {
                                        MessageBox.Show("Tìm thấy dữ liệu !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                        conn.Open();
                                        SqlCommand com = new SqlCommand("SELECT * FROM MONHOC where hocky like N'%" + txt_key.Text + "%' ", conn);
                                        SqlDataAdapter da = new SqlDataAdapter(com);
                                        DataTable dt = new DataTable();
                                        da.Fill(dt);
                                        ds.DataSource = dt;
                                        conn.Close();
                                    }
                                    else
                                    {
                                            MessageBox.Show("Không tìm thấy dữ liệu !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                            conn.Open();
                                            SqlCommand com = new SqlCommand("SELECT * FROM MONHOC where hocky like N'%" + txt_key.Text + "%' ", conn);
                                            SqlDataAdapter da = new SqlDataAdapter(com);
                                            DataTable dt = new DataTable();
                                            da.Fill(dt);
                                            ds.DataSource = dt;
                                            conn.Close();
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_export_Click(object sender, EventArgs e)
        {
            //khởi tạo excel
            Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();
            //khởi tạo WorkBook
            Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
            //khởi tạo WorkSheet
            Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
            worksheet = workbook.Sheets["Sheet1"];
            worksheet = workbook.ActiveSheet;
            app.Visible = true;
            //đổ dữ liệu vào sheet
            worksheet.Cells[1, 1] = "....., Ngày... tháng... năm......";
            worksheet.Cells[2, 1] = "Danh sách môn học";
            worksheet.Cells[3, 1] = "STT";
            worksheet.Cells[3, 2] = "Mã môn học";
            worksheet.Cells[3, 3] = "Tên môn học";
            worksheet.Cells[3, 4] = "Ngày đăng ký";
            worksheet.Cells[3, 5] = "Học kỳ";
            worksheet.Cells[3, 6] = "Số tín chỉ";
            worksheet.Cells[3, 7] = "Ngày bắt đầu";
            worksheet.Cells[3, 8] = "Ngày kết thúc";
            worksheet.Cells[3, 9] = "Tên giáo viên";
            worksheet.Cells[3, 10] = "Ghi chú";
            for (int i = 0; i < ds.RowCount - 1; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    worksheet.Cells[i + 4, 1] = i + 1;
                    worksheet.Cells[i + 4, j + 2] = ds.Rows[i].Cells[j].Value;
                }
            }
            worksheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
            worksheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;
            worksheet.PageSetup.LeftMargin = 0;
            worksheet.PageSetup.RightMargin = 0;
            worksheet.PageSetup.TopMargin = 0;
            worksheet.PageSetup.BottomMargin = 0;
            worksheet.PageSetup.CenterHorizontally = true;

            //định dạng cột
            worksheet.Range["A1"].ColumnWidth = 10;
            worksheet.Range["B1"].ColumnWidth = 11.3;
            worksheet.Range["C1"].ColumnWidth = 16.78;
            worksheet.Range["D1"].ColumnWidth = 11.89;
            worksheet.Range["E1"].ColumnWidth = 14.78;
            worksheet.Range["F1"].ColumnWidth = 7.11;

            worksheet.Range["A1", "F100"].Font.Name = "Times New Roman";
            worksheet.Range["A1", "F100"].Font.Size = 12;
            worksheet.Range["A1", "F1"].MergeCells = true;
            worksheet.Range["A2", "G2"].MergeCells = true;
            worksheet.Range["A2", "G2"].Font.Bold = true;

            worksheet.Range["A3", "F" + (ds.RowCount + 2)].Borders.LineStyle = 1;

            worksheet.Range["A1", "F1"].HorizontalAlignment = 4;
            worksheet.Range["A2", "F2"].HorizontalAlignment = 3;
            worksheet.Range["A3", "A" + (ds.RowCount + 2)].HorizontalAlignment = 3;
            worksheet.Range["A3", "F3"].HorizontalAlignment = 3;
        }
    }
}
