﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySinhVien
{
    public partial class frLogin : Form
    {
        connectDB c = new connectDB();
        int sai = 5;
        public frLogin()
        {
            InitializeComponent();
        }
        private String ChangeMD5(String strSource) { 
            System.Security.Cryptography.MD5CryptoServiceProvider x = new System.Security.Cryptography.MD5CryptoServiceProvider();//khởi tạo md5
            byte[] bs = System.Text.Encoding.UTF8.GetBytes(strSource);
            bs = x.ComputeHash(bs);
            System.Text.StringBuilder s = new System.Text.StringBuilder();
            foreach (Byte b in bs)
            {
                s.Append(b.ToString("X2").ToUpper());
            }
            return s.ToString();
        }
        private void btn_login_Click(object sender, EventArgs e)
        {
           
        }

        private void btn_register_Click(object sender, EventArgs e)
        {
            this.Hide();
            frRegister register = new frRegister();
            register.Show();
        }

       

       

        private void frLogin_Load(object sender, EventArgs e)
        {

        }

        private void btn_login_Click_1(object sender, EventArgs e)
        {
            try
            {
                
               
                String username = txt_username.Text;
                String password = txt_password.Text;
                if (username == "")
                {
                    MessageBox.Show("Bạn chưa nhập tên đăng nhập !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Question);
                    txt_username.Focus();
                }
                else if (password == "")
                {
                    MessageBox.Show("Bạn chưa nhập mật khẩu !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Question);
                    txt_password.Focus();
                }
                else
                {
                    string pass = ChangeMD5(password);
                    //lay dl trong bang tkamin
                    String sql = "SELECT * FROM TKAdmin WHERE username='" + username + "' AND password='" + pass + "'";
                    SqlCommand cmd = new SqlCommand(sql, c.Connect());
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    String tkuser = "";
                    String tkpass = "";
                    int status = 0;
                    foreach (DataRow TKAmin in dt.Rows)
                    {
                        tkuser = TKAmin["username"].ToString();
                        tkpass = TKAmin["password"].ToString();
                        status = Int32.Parse(TKAmin["status"].ToString());
                    }
                    if (sai != 0)
                    {

                        if (tkuser == username && tkpass == pass && status == 1)
                        {
                            this.Hide();
                            Begin begin = new Begin();
                            begin.Show();
                            /*begin.qly.Visible = false;
                            begin.diem.Visible = false;*/

                        }
                        else if (tkuser == username && tkpass == pass && status == 2)
                        {
                            this.Hide();
                            Begin begin = new Begin();
                            begin.Show();

                        }
                        else if (tkuser == username && tkpass == pass && status == 4)
                        {
                            this.Hide();
                            Begin begin = new Begin();
                            begin.Show();
                            begin.qly.Visible = false;
                            begin.nav_baocao.Visible = false;

                        }
                        else if (tkuser == username && tkpass == pass && status == 5)
                        {
                            this.Hide();
                            Begin begin = new Begin();
                            begin.Show();
                            begin.qly.Visible = false;
                            begin.diem.Visible = false;
                            begin.diem.Visible = false;
                            begin.nav_baocao.Visible = false;

                        }
                        else
                        {
                            MessageBox.Show("Tài khoản hoặc mật khẩu không đúng? Mời nhập lại", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            txt_username.Clear();
                            txt_password.Clear();
                            txt_username.Focus();
                        }
                    }
                    else
                    {
                        sai = sai - 1;
                        MessageBox.Show("Số lần bạn đăng nhập quá 5 lần !!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }



                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Đã có lỗi sảy ra", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                MessageBox.Show(ex.ToString());
            }
        }

        private void btn_register_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            frRegister register = new frRegister();
            register.Show();
        }

        private void btn_thoat_Click(object sender, EventArgs e)
        {
            DialogResult f = MessageBox.Show("Bạn có muốn thoát không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (f == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Close();
            fr_qunamk f = new fr_qunamk();
            f.Show();
        }
    }
}
