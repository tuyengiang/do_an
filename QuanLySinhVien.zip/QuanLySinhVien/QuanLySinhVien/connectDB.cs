﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLySinhVien
{
    class connectDB
    {
        SqlConnection conn;
       public SqlConnection Connect()
        {
            conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=QLSV;Integrated Security=True");
            return conn;
        }

        public void Open()
        {
            Connect();
            if (conn != null)
            {
                conn.Open();
            }
        }
        public void Close()
        {
            Connect();
            conn.Close();
            conn.Dispose();
            conn = null;
        }

        public void Excute(String sql)
        {
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.ExecuteNonQuery();
            conn.Close();
        }


       
    }
}
